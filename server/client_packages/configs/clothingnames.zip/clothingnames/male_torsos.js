exports = `{
    "0": {
        "0": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        }
    },
    "1": {
        "0": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        }
    },
    "2": {
        "0": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        }
    },
    "3": {
        "0": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        }
    },
    "4": {
        "0": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        }
    },
    "5": {
        "0": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        }
    },
    "6": {
        "0": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        }
    },
    "7": {
        "0": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        }
    },
    "8": {
        "0": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        }
    },
    "9": {
        "0": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        }
    },
    "10": {
        "0": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        }
    },
    "11": {
        "0": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        }
    },
    "12": {
        "0": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        }
    },
    "13": {
        "0": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        }
    },
    "14": {
        "0": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        }
    },
    "15": {
        "0": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        }
    },
    "16": {
        "0": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        }
    },
    "17": {
        "0": {
            "GXT": "CLO_LTSMT_0_0",
            "Localized": "Black Tact Gloves"
        },
        "1": {
            "GXT": "CLO_LTSMT_0_1",
            "Localized": "Gray Tact Gloves"
        },
        "2": {
            "GXT": "CLO_LTSMT_0_2",
            "Localized": "Charcoal Tact Gloves"
        },
        "3": {
            "GXT": "CLO_LTSMT_0_3",
            "Localized": "Tan Tact Gloves"
        },
        "4": {
            "GXT": "CLO_LTSMT_0_4",
            "Localized": "Forest Tact Gloves"
        }
    },
    "18": {
        "0": {
            "GXT": "CLO_LTSMT_1_0",
            "Localized": "Black Wool Gloves"
        },
        "1": {
            "GXT": "CLO_LTSMT_1_1",
            "Localized": "Gray Wool Gloves"
        },
        "2": {
            "GXT": "CLO_LTSMT_1_2",
            "Localized": "Charcoal Wool Gloves"
        },
        "3": {
            "GXT": "CLO_LTSMT_1_3",
            "Localized": "Tan Wool Gloves"
        },
        "4": {
            "GXT": "CLO_LTSMT_1_4",
            "Localized": "Green Wool Gloves"
        }
    },
    "19": {
        "0": {
            "GXT": "CLO_HSTM_G_0_0",
            "Localized": "Black Driving Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_0_1",
            "Localized": "Brown Driving Gloves"
        }
    },
    "20": {
        "0": {
            "GXT": "CLO_HSTM_G_0_0",
            "Localized": "Black Driving Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_0_1",
            "Localized": "Brown Driving Gloves"
        }
    },
    "21": {
        "0": {
            "GXT": "CLO_HSTM_G_0_0",
            "Localized": "Black Driving Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_0_1",
            "Localized": "Brown Driving Gloves"
        }
    },
    "22": {
        "0": {
            "GXT": "CLO_HSTM_G_0_0",
            "Localized": "Black Driving Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_0_1",
            "Localized": "Brown Driving Gloves"
        }
    },
    "23": {
        "0": {
            "GXT": "CLO_HSTM_G_0_0",
            "Localized": "Black Driving Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_0_1",
            "Localized": "Brown Driving Gloves"
        }
    },
    "24": {
        "0": {
            "GXT": "CLO_HSTM_G_0_0",
            "Localized": "Black Driving Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_0_1",
            "Localized": "Brown Driving Gloves"
        }
    },
    "25": {
        "0": {
            "GXT": "CLO_HSTM_G_0_0",
            "Localized": "Black Driving Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_0_1",
            "Localized": "Brown Driving Gloves"
        }
    },
    "26": {
        "0": {
            "GXT": "CLO_HSTM_G_0_0",
            "Localized": "Black Driving Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_0_1",
            "Localized": "Brown Driving Gloves"
        }
    },
    "27": {
        "0": {
            "GXT": "CLO_HSTM_G_0_0",
            "Localized": "Black Driving Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_0_1",
            "Localized": "Brown Driving Gloves"
        }
    },
    "28": {
        "0": {
            "GXT": "CLO_HSTM_G_0_0",
            "Localized": "Black Driving Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_0_1",
            "Localized": "Brown Driving Gloves"
        }
    },
    "29": {
        "0": {
            "GXT": "CLO_HSTM_G_0_0",
            "Localized": "Black Driving Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_0_1",
            "Localized": "Brown Driving Gloves"
        }
    },
    "30": {
        "0": {
            "GXT": "CLO_HSTM_G_1_0",
            "Localized": "Black Leather Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_1_1",
            "Localized": "Brown Leather Gloves"
        }
    },
    "31": {
        "0": {
            "GXT": "CLO_HSTM_G_1_0",
            "Localized": "Black Leather Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_1_1",
            "Localized": "Brown Leather Gloves"
        }
    },
    "32": {
        "0": {
            "GXT": "CLO_HSTM_G_1_0",
            "Localized": "Black Leather Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_1_1",
            "Localized": "Brown Leather Gloves"
        }
    },
    "33": {
        "0": {
            "GXT": "CLO_HSTM_G_1_0",
            "Localized": "Black Leather Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_1_1",
            "Localized": "Brown Leather Gloves"
        }
    },
    "34": {
        "0": {
            "GXT": "CLO_HSTM_G_1_0",
            "Localized": "Black Leather Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_1_1",
            "Localized": "Brown Leather Gloves"
        }
    },
    "35": {
        "0": {
            "GXT": "CLO_HSTM_G_1_0",
            "Localized": "Black Leather Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_1_1",
            "Localized": "Brown Leather Gloves"
        }
    },
    "36": {
        "0": {
            "GXT": "CLO_HSTM_G_1_0",
            "Localized": "Black Leather Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_1_1",
            "Localized": "Brown Leather Gloves"
        }
    },
    "37": {
        "0": {
            "GXT": "CLO_HSTM_G_1_0",
            "Localized": "Black Leather Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_1_1",
            "Localized": "Brown Leather Gloves"
        }
    },
    "38": {
        "0": {
            "GXT": "CLO_HSTM_G_1_0",
            "Localized": "Black Leather Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_1_1",
            "Localized": "Brown Leather Gloves"
        }
    },
    "39": {
        "0": {
            "GXT": "CLO_HSTM_G_1_0",
            "Localized": "Black Leather Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_1_1",
            "Localized": "Brown Leather Gloves"
        }
    },
    "40": {
        "0": {
            "GXT": "CLO_HSTM_G_1_0",
            "Localized": "Black Leather Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_1_1",
            "Localized": "Brown Leather Gloves"
        }
    },
    "41": {
        "0": {
            "GXT": "CLO_HSTM_G_2_0",
            "Localized": "Black Woolen Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_2_1",
            "Localized": "Gray Woolen Gloves"
        }
    },
    "42": {
        "0": {
            "GXT": "CLO_HSTM_G_2_0",
            "Localized": "Black Woolen Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_2_1",
            "Localized": "Gray Woolen Gloves"
        }
    },
    "43": {
        "0": {
            "GXT": "CLO_HSTM_G_2_0",
            "Localized": "Black Woolen Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_2_1",
            "Localized": "Gray Woolen Gloves"
        }
    },
    "44": {
        "0": {
            "GXT": "CLO_HSTM_G_2_0",
            "Localized": "Black Woolen Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_2_1",
            "Localized": "Gray Woolen Gloves"
        }
    },
    "45": {
        "0": {
            "GXT": "CLO_HSTM_G_2_0",
            "Localized": "Black Woolen Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_2_1",
            "Localized": "Gray Woolen Gloves"
        }
    },
    "46": {
        "0": {
            "GXT": "CLO_HSTM_G_2_0",
            "Localized": "Black Woolen Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_2_1",
            "Localized": "Gray Woolen Gloves"
        }
    },
    "47": {
        "0": {
            "GXT": "CLO_HSTM_G_2_0",
            "Localized": "Black Woolen Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_2_1",
            "Localized": "Gray Woolen Gloves"
        }
    },
    "48": {
        "0": {
            "GXT": "CLO_HSTM_G_2_0",
            "Localized": "Black Woolen Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_2_1",
            "Localized": "Gray Woolen Gloves"
        }
    },
    "49": {
        "0": {
            "GXT": "CLO_HSTM_G_2_0",
            "Localized": "Black Woolen Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_2_1",
            "Localized": "Gray Woolen Gloves"
        }
    },
    "50": {
        "0": {
            "GXT": "CLO_HSTM_G_2_0",
            "Localized": "Black Woolen Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_2_1",
            "Localized": "Gray Woolen Gloves"
        }
    },
    "51": {
        "0": {
            "GXT": "CLO_HSTM_G_2_0",
            "Localized": "Black Woolen Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_2_1",
            "Localized": "Gray Woolen Gloves"
        }
    },
    "52": {
        "0": {
            "GXT": "CLO_HSTM_G_3_0",
            "Localized": "Black Fingerless Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_3_1",
            "Localized": "Gray Fingerless Gloves"
        }
    },
    "53": {
        "0": {
            "GXT": "CLO_HSTM_G_3_0",
            "Localized": "Black Fingerless Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_3_1",
            "Localized": "Gray Fingerless Gloves"
        }
    },
    "54": {
        "0": {
            "GXT": "CLO_HSTM_G_3_0",
            "Localized": "Black Fingerless Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_3_1",
            "Localized": "Gray Fingerless Gloves"
        }
    },
    "55": {
        "0": {
            "GXT": "CLO_HSTM_G_3_0",
            "Localized": "Black Fingerless Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_3_1",
            "Localized": "Gray Fingerless Gloves"
        }
    },
    "56": {
        "0": {
            "GXT": "CLO_HSTM_G_3_0",
            "Localized": "Black Fingerless Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_3_1",
            "Localized": "Gray Fingerless Gloves"
        }
    },
    "57": {
        "0": {
            "GXT": "CLO_HSTM_G_3_0",
            "Localized": "Black Fingerless Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_3_1",
            "Localized": "Gray Fingerless Gloves"
        }
    },
    "58": {
        "0": {
            "GXT": "CLO_HSTM_G_3_0",
            "Localized": "Black Fingerless Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_3_1",
            "Localized": "Gray Fingerless Gloves"
        }
    },
    "59": {
        "0": {
            "GXT": "CLO_HSTM_G_3_0",
            "Localized": "Black Fingerless Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_3_1",
            "Localized": "Gray Fingerless Gloves"
        }
    },
    "60": {
        "0": {
            "GXT": "CLO_HSTM_G_3_0",
            "Localized": "Black Fingerless Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_3_1",
            "Localized": "Gray Fingerless Gloves"
        }
    },
    "61": {
        "0": {
            "GXT": "CLO_HSTM_G_3_0",
            "Localized": "Black Fingerless Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_3_1",
            "Localized": "Gray Fingerless Gloves"
        }
    },
    "62": {
        "0": {
            "GXT": "CLO_HSTM_G_3_0",
            "Localized": "Black Fingerless Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_3_1",
            "Localized": "Gray Fingerless Gloves"
        }
    },
    "63": {
        "0": {
            "GXT": "CLO_HSTM_G_6_0",
            "Localized": "Refuse Collector Gloves"
        }
    },
    "64": {
        "0": {
            "GXT": "CLO_HSTM_G_6_0",
            "Localized": "Refuse Collector Gloves"
        }
    },
    "65": {
        "0": {
            "GXT": "CLO_HSTM_G_6_0",
            "Localized": "Refuse Collector Gloves"
        }
    },
    "66": {
        "0": {
            "GXT": "CLO_HSTM_G_6_0",
            "Localized": "Refuse Collector Gloves"
        }
    },
    "67": {
        "0": {
            "GXT": "CLO_HSTM_G_6_0",
            "Localized": "Refuse Collector Gloves"
        }
    },
    "68": {
        "0": {
            "GXT": "CLO_HSTM_G_6_0",
            "Localized": "Refuse Collector Gloves"
        }
    },
    "69": {
        "0": {
            "GXT": "CLO_HSTM_G_6_0",
            "Localized": "Refuse Collector Gloves"
        }
    },
    "70": {
        "0": {
            "GXT": "CLO_HSTM_G_6_0",
            "Localized": "Refuse Collector Gloves"
        }
    },
    "71": {
        "0": {
            "GXT": "CLO_HSTM_G_6_0",
            "Localized": "Refuse Collector Gloves"
        }
    },
    "72": {
        "0": {
            "GXT": "CLO_HSTM_G_6_0",
            "Localized": "Refuse Collector Gloves"
        }
    },
    "73": {
        "0": {
            "GXT": "CLO_HSTM_G_6_0",
            "Localized": "Refuse Collector Gloves"
        }
    },
    "74": {
        "0": {
            "GXT": "CLO_HSTM_G_4_0",
            "Localized": "White Cotton Gloves"
        }
    },
    "75": {
        "0": {
            "GXT": "CLO_HSTM_G_4_0",
            "Localized": "White Cotton Gloves"
        }
    },
    "76": {
        "0": {
            "GXT": "CLO_HSTM_G_4_0",
            "Localized": "White Cotton Gloves"
        }
    },
    "77": {
        "0": {
            "GXT": "CLO_HSTM_G_4_0",
            "Localized": "White Cotton Gloves"
        }
    },
    "78": {
        "0": {
            "GXT": "CLO_HSTM_G_4_0",
            "Localized": "White Cotton Gloves"
        }
    },
    "79": {
        "0": {
            "GXT": "CLO_HSTM_G_4_0",
            "Localized": "White Cotton Gloves"
        }
    },
    "80": {
        "0": {
            "GXT": "CLO_HSTM_G_4_0",
            "Localized": "White Cotton Gloves"
        }
    },
    "81": {
        "0": {
            "GXT": "CLO_HSTM_G_4_0",
            "Localized": "White Cotton Gloves"
        }
    },
    "82": {
        "0": {
            "GXT": "CLO_HSTM_G_4_0",
            "Localized": "White Cotton Gloves"
        }
    },
    "83": {
        "0": {
            "GXT": "CLO_HSTM_G_4_0",
            "Localized": "White Cotton Gloves"
        }
    },
    "84": {
        "0": {
            "GXT": "CLO_HSTM_G_4_0",
            "Localized": "White Cotton Gloves"
        }
    },
    "85": {
        "0": {
            "GXT": "CLO_HSTM_G_5_0",
            "Localized": "Blue Surgical Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_5_1",
            "Localized": "White Surgical Gloves"
        }
    },
    "86": {
        "0": {
            "GXT": "CLO_HSTM_G_5_0",
            "Localized": "Blue Surgical Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_5_1",
            "Localized": "White Surgical Gloves"
        }
    },
    "87": {
        "0": {
            "GXT": "CLO_HSTM_G_5_0",
            "Localized": "Blue Surgical Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_5_1",
            "Localized": "White Surgical Gloves"
        }
    },
    "88": {
        "0": {
            "GXT": "CLO_HSTM_G_5_0",
            "Localized": "Blue Surgical Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_5_1",
            "Localized": "White Surgical Gloves"
        }
    },
    "89": {
        "0": {
            "GXT": "CLO_HSTM_G_5_0",
            "Localized": "Blue Surgical Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_5_1",
            "Localized": "White Surgical Gloves"
        }
    },
    "90": {
        "0": {
            "GXT": "CLO_HSTM_G_5_0",
            "Localized": "Blue Surgical Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_5_1",
            "Localized": "White Surgical Gloves"
        }
    },
    "91": {
        "0": {
            "GXT": "CLO_HSTM_G_5_0",
            "Localized": "Blue Surgical Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_5_1",
            "Localized": "White Surgical Gloves"
        }
    },
    "92": {
        "0": {
            "GXT": "CLO_HSTM_G_5_0",
            "Localized": "Blue Surgical Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_5_1",
            "Localized": "White Surgical Gloves"
        }
    },
    "93": {
        "0": {
            "GXT": "CLO_HSTM_G_5_0",
            "Localized": "Blue Surgical Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_5_1",
            "Localized": "White Surgical Gloves"
        }
    },
    "94": {
        "0": {
            "GXT": "CLO_HSTM_G_5_0",
            "Localized": "Blue Surgical Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_5_1",
            "Localized": "White Surgical Gloves"
        }
    },
    "95": {
        "0": {
            "GXT": "CLO_HSTM_G_5_0",
            "Localized": "Blue Surgical Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_5_1",
            "Localized": "White Surgical Gloves"
        }
    },
    "96": {
        "0": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        }
    },
    "97": {
        "0": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        }
    },
    "98": {
        "0": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "1": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "2": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        }
    },
    "99": {
        "0": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "1": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "2": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "3": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "4": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "5": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "6": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "7": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "8": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "9": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        }
    },
    "100": {
        "0": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "1": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "2": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "3": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "4": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "5": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "6": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "7": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "8": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "9": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        }
    },
    "101": {
        "0": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "1": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "2": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "3": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "4": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "5": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "6": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "7": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "8": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "9": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        }
    },
    "102": {
        "0": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "1": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "2": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "3": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "4": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "5": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "6": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "7": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "8": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "9": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        }
    },
    "103": {
        "0": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "1": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "2": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "3": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "4": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "5": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "6": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "7": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "8": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "9": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        }
    },
    "104": {
        "0": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "1": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "2": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "3": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "4": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "5": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "6": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "7": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "8": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "9": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        }
    },
    "105": {
        "0": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "1": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "2": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "3": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "4": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "5": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "6": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "7": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "8": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "9": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        }
    },
    "106": {
        "0": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "1": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "2": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "3": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "4": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "5": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "6": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "7": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "8": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "9": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        }
    },
    "107": {
        "0": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "1": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "2": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "3": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "4": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "5": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "6": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "7": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "8": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "9": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        }
    },
    "108": {
        "0": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "1": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "2": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "3": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "4": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "5": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "6": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "7": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "8": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "9": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        }
    },
    "109": {
        "0": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "1": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "2": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "3": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "4": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "5": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "6": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "7": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "8": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "9": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        }
    },
    "110": {
        "0": {
            "GXT": "CLO_STM_GL_0_0",
            "Localized": "Racesuit Gloves"
        },
        "1": {
            "GXT": "CLO_STM_GL_0_0",
            "Localized": "Racesuit Gloves"
        },
        "2": {
            "GXT": "CLO_STM_GL_0_0",
            "Localized": "Racesuit Gloves"
        },
        "3": {
            "GXT": "CLO_STM_GL_0_0",
            "Localized": "Racesuit Gloves"
        },
        "4": {
            "GXT": "CLO_STM_GL_0_0",
            "Localized": "Racesuit Gloves"
        },
        "5": {
            "GXT": "CLO_STM_GL_0_0",
            "Localized": "Racesuit Gloves"
        },
        "6": {
            "GXT": "CLO_STM_GL_0_0",
            "Localized": "Racesuit Gloves"
        },
        "7": {
            "GXT": "CLO_STM_GL_0_0",
            "Localized": "Racesuit Gloves"
        },
        "8": {
            "GXT": "CLO_STM_GL_0_0",
            "Localized": "Racesuit Gloves"
        },
        "9": {
            "GXT": "CLO_STM_GL_0_0",
            "Localized": "Racesuit Gloves"
        },
        "10": {
            "GXT": "CLO_STM_GL_0_0",
            "Localized": "Racesuit Gloves"
        },
        "11": {
            "GXT": "CLO_STM_GL_0_0",
            "Localized": "Racesuit Gloves"
        }
    },
    "111": {
        "0": {
            "GXT": "CLO_STM_GL_1_0",
            "Localized": "Motocross Gloves"
        },
        "1": {
            "GXT": "CLO_STM_GL_1_0",
            "Localized": "Motocross Gloves"
        },
        "2": {
            "GXT": "CLO_STM_GL_1_0",
            "Localized": "Motocross Gloves"
        },
        "3": {
            "GXT": "CLO_STM_GL_1_0",
            "Localized": "Motocross Gloves"
        },
        "4": {
            "GXT": "CLO_STM_GL_1_0",
            "Localized": "Motocross Gloves"
        },
        "5": {
            "GXT": "CLO_STM_GL_1_0",
            "Localized": "Motocross Gloves"
        },
        "6": {
            "GXT": "CLO_STM_GL_1_0",
            "Localized": "Motocross Gloves"
        },
        "7": {
            "GXT": "CLO_STM_GL_1_0",
            "Localized": "Motocross Gloves"
        },
        "8": {
            "GXT": "CLO_STM_GL_1_0",
            "Localized": "Motocross Gloves"
        },
        "9": {
            "GXT": "CLO_STM_GL_1_0",
            "Localized": "Motocross Gloves"
        },
        "10": {
            "GXT": "CLO_STM_GL_1_0",
            "Localized": "Motocross Gloves"
        },
        "11": {
            "GXT": "CLO_STM_GL_1_0",
            "Localized": "Motocross Gloves"
        },
        "12": {
            "GXT": "CLO_STM_GL_1_0",
            "Localized": "Motocross Gloves"
        },
        "13": {
            "GXT": "CLO_STM_GL_1_0",
            "Localized": "Motocross Gloves"
        },
        "14": {
            "GXT": "CLO_STM_GL_1_0",
            "Localized": "Motocross Gloves"
        },
        "15": {
            "GXT": "CLO_STM_GL_1_0",
            "Localized": "Motocross Gloves"
        }
    },
    "112": {
        "0": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        }
    },
    "113": {
        "0": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        }
    },
    "114": {
        "0": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        }
    },
    "115": {
        "0": {
            "GXT": "CLO_HSTM_G_0_0",
            "Localized": "Black Driving Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_0_1",
            "Localized": "Brown Driving Gloves"
        }
    },
    "116": {
        "0": {
            "GXT": "CLO_HSTM_G_1_0",
            "Localized": "Black Leather Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_1_1",
            "Localized": "Brown Leather Gloves"
        }
    },
    "117": {
        "0": {
            "GXT": "CLO_HSTM_G_2_0",
            "Localized": "Black Woolen Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_2_1",
            "Localized": "Gray Woolen Gloves"
        }
    },
    "118": {
        "0": {
            "GXT": "CLO_HSTM_G_3_0",
            "Localized": "Black Fingerless Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_3_1",
            "Localized": "Gray Fingerless Gloves"
        }
    },
    "119": {
        "0": {
            "GXT": "CLO_HSTM_G_6_0",
            "Localized": "Refuse Collector Gloves"
        }
    },
    "120": {
        "0": {
            "GXT": "CLO_HSTM_G_4_0",
            "Localized": "White Cotton Gloves"
        }
    },
    "121": {
        "0": {
            "GXT": "CLO_HSTM_G_5_0",
            "Localized": "Blue Surgical Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_5_1",
            "Localized": "White Surgical Gloves"
        }
    },
    "122": {
        "0": {
            "GXT": "CLO_HSTM_G_0_0",
            "Localized": "Black Driving Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_0_1",
            "Localized": "Brown Driving Gloves"
        }
    },
    "123": {
        "0": {
            "GXT": "CLO_HSTM_G_1_0",
            "Localized": "Black Leather Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_1_1",
            "Localized": "Brown Leather Gloves"
        }
    },
    "124": {
        "0": {
            "GXT": "CLO_HSTM_G_2_0",
            "Localized": "Black Woolen Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_2_1",
            "Localized": "Gray Woolen Gloves"
        }
    },
    "125": {
        "0": {
            "GXT": "CLO_HSTM_G_3_0",
            "Localized": "Black Fingerless Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_3_1",
            "Localized": "Gray Fingerless Gloves"
        }
    },
    "126": {
        "0": {
            "GXT": "CLO_HSTM_G_6_0",
            "Localized": "Refuse Collector Gloves"
        }
    },
    "127": {
        "0": {
            "GXT": "CLO_HSTM_G_4_0",
            "Localized": "White Cotton Gloves"
        }
    },
    "128": {
        "0": {
            "GXT": "CLO_HSTM_G_5_0",
            "Localized": "Blue Surgical Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_5_1",
            "Localized": "White Surgical Gloves"
        }
    },
    "129": {
        "0": {
            "GXT": "CLO_HSTM_G_0_0",
            "Localized": "Black Driving Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_0_1",
            "Localized": "Brown Driving Gloves"
        }
    },
    "130": {
        "0": {
            "GXT": "CLO_HSTM_G_1_0",
            "Localized": "Black Leather Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_1_1",
            "Localized": "Brown Leather Gloves"
        }
    },
    "131": {
        "0": {
            "GXT": "CLO_HSTM_G_2_0",
            "Localized": "Black Woolen Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_2_1",
            "Localized": "Gray Woolen Gloves"
        }
    },
    "132": {
        "0": {
            "GXT": "CLO_HSTM_G_3_0",
            "Localized": "Black Fingerless Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_3_1",
            "Localized": "Gray Fingerless Gloves"
        }
    },
    "133": {
        "0": {
            "GXT": "CLO_HSTM_G_6_0",
            "Localized": "Refuse Collector Gloves"
        }
    },
    "134": {
        "0": {
            "GXT": "CLO_HSTM_G_4_0",
            "Localized": "White Cotton Gloves"
        }
    },
    "135": {
        "0": {
            "GXT": "CLO_HSTM_G_5_0",
            "Localized": "Blue Surgical Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_5_1",
            "Localized": "White Surgical Gloves"
        }
    },
    "136": {
        "0": {
            "GXT": "CLO_GRM_G_0_0",
            "Localized": "Blue Digital Armored"
        },
        "1": {
            "GXT": "CLO_GRM_G_0_1",
            "Localized": "Brown Digital Armored"
        },
        "2": {
            "GXT": "CLO_GRM_G_0_2",
            "Localized": "Green Digital Armored"
        },
        "3": {
            "GXT": "CLO_GRM_G_0_3",
            "Localized": "Gray Digital Armored"
        },
        "4": {
            "GXT": "CLO_GRM_G_0_4",
            "Localized": "Peach Digital Armored"
        },
        "5": {
            "GXT": "CLO_GRM_G_0_5",
            "Localized": "Fall Armored"
        },
        "6": {
            "GXT": "CLO_GRM_G_0_6",
            "Localized": "Dark Woodland Armored"
        },
        "7": {
            "GXT": "CLO_GRM_G_0_7",
            "Localized": "Crosshatch Armored"
        },
        "8": {
            "GXT": "CLO_GRM_G_0_8",
            "Localized": "Moss Digital Armored"
        },
        "9": {
            "GXT": "CLO_GRM_G_0_9",
            "Localized": "Gray Woodland Armored"
        },
        "10": {
            "GXT": "CLO_GRM_G_0_10",
            "Localized": "Aqua Camo Armored"
        },
        "11": {
            "GXT": "CLO_GRM_G_0_11",
            "Localized": "Splinter Armored"
        },
        "12": {
            "GXT": "CLO_GRM_G_0_12",
            "Localized": "Contrast Camo Armored"
        },
        "13": {
            "GXT": "CLO_GRM_G_0_13",
            "Localized": "Cobble Armored"
        },
        "14": {
            "GXT": "CLO_GRM_G_0_14",
            "Localized": "Peach Camo Armored"
        },
        "15": {
            "GXT": "CLO_GRM_G_0_15",
            "Localized": "Brushstroke Armored"
        },
        "16": {
            "GXT": "CLO_GRM_G_0_16",
            "Localized": "Flecktarn Armored"
        },
        "17": {
            "GXT": "CLO_GRM_G_0_17",
            "Localized": "Light Woodland Armored"
        },
        "18": {
            "GXT": "CLO_GRM_G_0_18",
            "Localized": "Moss Armored"
        },
        "19": {
            "GXT": "CLO_GRM_G_0_19",
            "Localized": "Sand Armored"
        }
    },
    "137": {
        "0": {
            "GXT": "CLO_GRM_G_1_0",
            "Localized": "Blue Digital Tactical"
        },
        "1": {
            "GXT": "CLO_GRM_G_1_1",
            "Localized": "Brown Digital Tactical"
        },
        "2": {
            "GXT": "CLO_GRM_G_1_2",
            "Localized": "Green Digital Tactical"
        },
        "3": {
            "GXT": "CLO_GRM_G_1_3",
            "Localized": "Gray Digital Tactical"
        },
        "4": {
            "GXT": "CLO_GRM_G_1_4",
            "Localized": "Peach Digital Tactical"
        },
        "5": {
            "GXT": "CLO_GRM_G_1_5",
            "Localized": "Fall Tactical"
        },
        "6": {
            "GXT": "CLO_GRM_G_1_6",
            "Localized": "Dark Woodland Tactical"
        },
        "7": {
            "GXT": "CLO_GRM_G_1_7",
            "Localized": "Crosshatch Tactical"
        },
        "8": {
            "GXT": "CLO_GRM_G_1_8",
            "Localized": "Moss Digital Tactical"
        },
        "9": {
            "GXT": "CLO_GRM_G_1_9",
            "Localized": "Gray Woodland Tactical"
        },
        "10": {
            "GXT": "CLO_GRM_G_1_10",
            "Localized": "Aqua Camo Tactical"
        },
        "11": {
            "GXT": "CLO_GRM_G_1_11",
            "Localized": "Splinter Tactical"
        },
        "12": {
            "GXT": "CLO_GRM_G_1_12",
            "Localized": "Contrast Camo Tactical"
        },
        "13": {
            "GXT": "CLO_GRM_G_1_13",
            "Localized": "Cobble Tactical"
        },
        "14": {
            "GXT": "CLO_GRM_G_1_14",
            "Localized": "Peach Camo Tactical"
        },
        "15": {
            "GXT": "CLO_GRM_G_1_15",
            "Localized": "Brushstroke Tactical"
        },
        "16": {
            "GXT": "CLO_GRM_G_1_16",
            "Localized": "Flecktarn Tactical"
        },
        "17": {
            "GXT": "CLO_GRM_G_1_17",
            "Localized": "Light Woodland Tactical"
        },
        "18": {
            "GXT": "CLO_GRM_G_1_18",
            "Localized": "Moss Tactical"
        },
        "19": {
            "GXT": "CLO_GRM_G_1_19",
            "Localized": "Sand Tactical"
        }
    },
    "138": {
        "0": {
            "GXT": "CLO_GRM_G_0_0",
            "Localized": "Blue Digital Armored"
        },
        "1": {
            "GXT": "CLO_GRM_G_0_1",
            "Localized": "Brown Digital Armored"
        },
        "2": {
            "GXT": "CLO_GRM_G_0_2",
            "Localized": "Green Digital Armored"
        },
        "3": {
            "GXT": "CLO_GRM_G_0_3",
            "Localized": "Gray Digital Armored"
        },
        "4": {
            "GXT": "CLO_GRM_G_0_4",
            "Localized": "Peach Digital Armored"
        },
        "5": {
            "GXT": "CLO_GRM_G_0_5",
            "Localized": "Fall Armored"
        },
        "6": {
            "GXT": "CLO_GRM_G_0_6",
            "Localized": "Dark Woodland Armored"
        },
        "7": {
            "GXT": "CLO_GRM_G_0_7",
            "Localized": "Crosshatch Armored"
        },
        "8": {
            "GXT": "CLO_GRM_G_0_8",
            "Localized": "Moss Digital Armored"
        },
        "9": {
            "GXT": "CLO_GRM_G_0_9",
            "Localized": "Gray Woodland Armored"
        },
        "10": {
            "GXT": "CLO_GRM_G_0_10",
            "Localized": "Aqua Camo Armored"
        },
        "11": {
            "GXT": "CLO_GRM_G_0_11",
            "Localized": "Splinter Armored"
        },
        "12": {
            "GXT": "CLO_GRM_G_0_12",
            "Localized": "Contrast Camo Armored"
        },
        "13": {
            "GXT": "CLO_GRM_G_0_13",
            "Localized": "Cobble Armored"
        },
        "14": {
            "GXT": "CLO_GRM_G_0_14",
            "Localized": "Peach Camo Armored"
        },
        "15": {
            "GXT": "CLO_GRM_G_0_15",
            "Localized": "Brushstroke Armored"
        },
        "16": {
            "GXT": "CLO_GRM_G_0_16",
            "Localized": "Flecktarn Armored"
        },
        "17": {
            "GXT": "CLO_GRM_G_0_17",
            "Localized": "Light Woodland Armored"
        },
        "18": {
            "GXT": "CLO_GRM_G_0_18",
            "Localized": "Moss Armored"
        },
        "19": {
            "GXT": "CLO_GRM_G_0_19",
            "Localized": "Sand Armored"
        }
    },
    "139": {
        "0": {
            "GXT": "CLO_GRM_G_0_0",
            "Localized": "Blue Digital Armored"
        },
        "1": {
            "GXT": "CLO_GRM_G_0_1",
            "Localized": "Brown Digital Armored"
        },
        "2": {
            "GXT": "CLO_GRM_G_0_2",
            "Localized": "Green Digital Armored"
        },
        "3": {
            "GXT": "CLO_GRM_G_0_3",
            "Localized": "Gray Digital Armored"
        },
        "4": {
            "GXT": "CLO_GRM_G_0_4",
            "Localized": "Peach Digital Armored"
        },
        "5": {
            "GXT": "CLO_GRM_G_0_5",
            "Localized": "Fall Armored"
        },
        "6": {
            "GXT": "CLO_GRM_G_0_6",
            "Localized": "Dark Woodland Armored"
        },
        "7": {
            "GXT": "CLO_GRM_G_0_7",
            "Localized": "Crosshatch Armored"
        },
        "8": {
            "GXT": "CLO_GRM_G_0_8",
            "Localized": "Moss Digital Armored"
        },
        "9": {
            "GXT": "CLO_GRM_G_0_9",
            "Localized": "Gray Woodland Armored"
        },
        "10": {
            "GXT": "CLO_GRM_G_0_10",
            "Localized": "Aqua Camo Armored"
        },
        "11": {
            "GXT": "CLO_GRM_G_0_11",
            "Localized": "Splinter Armored"
        },
        "12": {
            "GXT": "CLO_GRM_G_0_12",
            "Localized": "Contrast Camo Armored"
        },
        "13": {
            "GXT": "CLO_GRM_G_0_13",
            "Localized": "Cobble Armored"
        },
        "14": {
            "GXT": "CLO_GRM_G_0_14",
            "Localized": "Peach Camo Armored"
        },
        "15": {
            "GXT": "CLO_GRM_G_0_15",
            "Localized": "Brushstroke Armored"
        },
        "16": {
            "GXT": "CLO_GRM_G_0_16",
            "Localized": "Flecktarn Armored"
        },
        "17": {
            "GXT": "CLO_GRM_G_0_17",
            "Localized": "Light Woodland Armored"
        },
        "18": {
            "GXT": "CLO_GRM_G_0_18",
            "Localized": "Moss Armored"
        },
        "19": {
            "GXT": "CLO_GRM_G_0_19",
            "Localized": "Sand Armored"
        }
    },
    "140": {
        "0": {
            "GXT": "CLO_GRM_G_0_0",
            "Localized": "Blue Digital Armored"
        },
        "1": {
            "GXT": "CLO_GRM_G_0_1",
            "Localized": "Brown Digital Armored"
        },
        "2": {
            "GXT": "CLO_GRM_G_0_2",
            "Localized": "Green Digital Armored"
        },
        "3": {
            "GXT": "CLO_GRM_G_0_3",
            "Localized": "Gray Digital Armored"
        },
        "4": {
            "GXT": "CLO_GRM_G_0_4",
            "Localized": "Peach Digital Armored"
        },
        "5": {
            "GXT": "CLO_GRM_G_0_5",
            "Localized": "Fall Armored"
        },
        "6": {
            "GXT": "CLO_GRM_G_0_6",
            "Localized": "Dark Woodland Armored"
        },
        "7": {
            "GXT": "CLO_GRM_G_0_7",
            "Localized": "Crosshatch Armored"
        },
        "8": {
            "GXT": "CLO_GRM_G_0_8",
            "Localized": "Moss Digital Armored"
        },
        "9": {
            "GXT": "CLO_GRM_G_0_9",
            "Localized": "Gray Woodland Armored"
        },
        "10": {
            "GXT": "CLO_GRM_G_0_10",
            "Localized": "Aqua Camo Armored"
        },
        "11": {
            "GXT": "CLO_GRM_G_0_11",
            "Localized": "Splinter Armored"
        },
        "12": {
            "GXT": "CLO_GRM_G_0_12",
            "Localized": "Contrast Camo Armored"
        },
        "13": {
            "GXT": "CLO_GRM_G_0_13",
            "Localized": "Cobble Armored"
        },
        "14": {
            "GXT": "CLO_GRM_G_0_14",
            "Localized": "Peach Camo Armored"
        },
        "15": {
            "GXT": "CLO_GRM_G_0_15",
            "Localized": "Brushstroke Armored"
        },
        "16": {
            "GXT": "CLO_GRM_G_0_16",
            "Localized": "Flecktarn Armored"
        },
        "17": {
            "GXT": "CLO_GRM_G_0_17",
            "Localized": "Light Woodland Armored"
        },
        "18": {
            "GXT": "CLO_GRM_G_0_18",
            "Localized": "Moss Armored"
        },
        "19": {
            "GXT": "CLO_GRM_G_0_19",
            "Localized": "Sand Armored"
        }
    },
    "141": {
        "0": {
            "GXT": "CLO_GRM_G_0_0",
            "Localized": "Blue Digital Armored"
        },
        "1": {
            "GXT": "CLO_GRM_G_0_1",
            "Localized": "Brown Digital Armored"
        },
        "2": {
            "GXT": "CLO_GRM_G_0_2",
            "Localized": "Green Digital Armored"
        },
        "3": {
            "GXT": "CLO_GRM_G_0_3",
            "Localized": "Gray Digital Armored"
        },
        "4": {
            "GXT": "CLO_GRM_G_0_4",
            "Localized": "Peach Digital Armored"
        },
        "5": {
            "GXT": "CLO_GRM_G_0_5",
            "Localized": "Fall Armored"
        },
        "6": {
            "GXT": "CLO_GRM_G_0_6",
            "Localized": "Dark Woodland Armored"
        },
        "7": {
            "GXT": "CLO_GRM_G_0_7",
            "Localized": "Crosshatch Armored"
        },
        "8": {
            "GXT": "CLO_GRM_G_0_8",
            "Localized": "Moss Digital Armored"
        },
        "9": {
            "GXT": "CLO_GRM_G_0_9",
            "Localized": "Gray Woodland Armored"
        },
        "10": {
            "GXT": "CLO_GRM_G_0_10",
            "Localized": "Aqua Camo Armored"
        },
        "11": {
            "GXT": "CLO_GRM_G_0_11",
            "Localized": "Splinter Armored"
        },
        "12": {
            "GXT": "CLO_GRM_G_0_12",
            "Localized": "Contrast Camo Armored"
        },
        "13": {
            "GXT": "CLO_GRM_G_0_13",
            "Localized": "Cobble Armored"
        },
        "14": {
            "GXT": "CLO_GRM_G_0_14",
            "Localized": "Peach Camo Armored"
        },
        "15": {
            "GXT": "CLO_GRM_G_0_15",
            "Localized": "Brushstroke Armored"
        },
        "16": {
            "GXT": "CLO_GRM_G_0_16",
            "Localized": "Flecktarn Armored"
        },
        "17": {
            "GXT": "CLO_GRM_G_0_17",
            "Localized": "Light Woodland Armored"
        },
        "18": {
            "GXT": "CLO_GRM_G_0_18",
            "Localized": "Moss Armored"
        },
        "19": {
            "GXT": "CLO_GRM_G_0_19",
            "Localized": "Sand Armored"
        }
    },
    "142": {
        "0": {
            "GXT": "CLO_GRM_G_0_0",
            "Localized": "Blue Digital Armored"
        },
        "1": {
            "GXT": "CLO_GRM_G_0_1",
            "Localized": "Brown Digital Armored"
        },
        "2": {
            "GXT": "CLO_GRM_G_0_2",
            "Localized": "Green Digital Armored"
        },
        "3": {
            "GXT": "CLO_GRM_G_0_3",
            "Localized": "Gray Digital Armored"
        },
        "4": {
            "GXT": "CLO_GRM_G_0_4",
            "Localized": "Peach Digital Armored"
        },
        "5": {
            "GXT": "CLO_GRM_G_0_5",
            "Localized": "Fall Armored"
        },
        "6": {
            "GXT": "CLO_GRM_G_0_6",
            "Localized": "Dark Woodland Armored"
        },
        "7": {
            "GXT": "CLO_GRM_G_0_7",
            "Localized": "Crosshatch Armored"
        },
        "8": {
            "GXT": "CLO_GRM_G_0_8",
            "Localized": "Moss Digital Armored"
        },
        "9": {
            "GXT": "CLO_GRM_G_0_9",
            "Localized": "Gray Woodland Armored"
        },
        "10": {
            "GXT": "CLO_GRM_G_0_10",
            "Localized": "Aqua Camo Armored"
        },
        "11": {
            "GXT": "CLO_GRM_G_0_11",
            "Localized": "Splinter Armored"
        },
        "12": {
            "GXT": "CLO_GRM_G_0_12",
            "Localized": "Contrast Camo Armored"
        },
        "13": {
            "GXT": "CLO_GRM_G_0_13",
            "Localized": "Cobble Armored"
        },
        "14": {
            "GXT": "CLO_GRM_G_0_14",
            "Localized": "Peach Camo Armored"
        },
        "15": {
            "GXT": "CLO_GRM_G_0_15",
            "Localized": "Brushstroke Armored"
        },
        "16": {
            "GXT": "CLO_GRM_G_0_16",
            "Localized": "Flecktarn Armored"
        },
        "17": {
            "GXT": "CLO_GRM_G_0_17",
            "Localized": "Light Woodland Armored"
        },
        "18": {
            "GXT": "CLO_GRM_G_0_18",
            "Localized": "Moss Armored"
        },
        "19": {
            "GXT": "CLO_GRM_G_0_19",
            "Localized": "Sand Armored"
        }
    },
    "143": {
        "0": {
            "GXT": "CLO_GRM_G_0_0",
            "Localized": "Blue Digital Armored"
        },
        "1": {
            "GXT": "CLO_GRM_G_0_1",
            "Localized": "Brown Digital Armored"
        },
        "2": {
            "GXT": "CLO_GRM_G_0_2",
            "Localized": "Green Digital Armored"
        },
        "3": {
            "GXT": "CLO_GRM_G_0_3",
            "Localized": "Gray Digital Armored"
        },
        "4": {
            "GXT": "CLO_GRM_G_0_4",
            "Localized": "Peach Digital Armored"
        },
        "5": {
            "GXT": "CLO_GRM_G_0_5",
            "Localized": "Fall Armored"
        },
        "6": {
            "GXT": "CLO_GRM_G_0_6",
            "Localized": "Dark Woodland Armored"
        },
        "7": {
            "GXT": "CLO_GRM_G_0_7",
            "Localized": "Crosshatch Armored"
        },
        "8": {
            "GXT": "CLO_GRM_G_0_8",
            "Localized": "Moss Digital Armored"
        },
        "9": {
            "GXT": "CLO_GRM_G_0_9",
            "Localized": "Gray Woodland Armored"
        },
        "10": {
            "GXT": "CLO_GRM_G_0_10",
            "Localized": "Aqua Camo Armored"
        },
        "11": {
            "GXT": "CLO_GRM_G_0_11",
            "Localized": "Splinter Armored"
        },
        "12": {
            "GXT": "CLO_GRM_G_0_12",
            "Localized": "Contrast Camo Armored"
        },
        "13": {
            "GXT": "CLO_GRM_G_0_13",
            "Localized": "Cobble Armored"
        },
        "14": {
            "GXT": "CLO_GRM_G_0_14",
            "Localized": "Peach Camo Armored"
        },
        "15": {
            "GXT": "CLO_GRM_G_0_15",
            "Localized": "Brushstroke Armored"
        },
        "16": {
            "GXT": "CLO_GRM_G_0_16",
            "Localized": "Flecktarn Armored"
        },
        "17": {
            "GXT": "CLO_GRM_G_0_17",
            "Localized": "Light Woodland Armored"
        },
        "18": {
            "GXT": "CLO_GRM_G_0_18",
            "Localized": "Moss Armored"
        },
        "19": {
            "GXT": "CLO_GRM_G_0_19",
            "Localized": "Sand Armored"
        }
    },
    "144": {
        "0": {
            "GXT": "CLO_GRM_G_0_0",
            "Localized": "Blue Digital Armored"
        },
        "1": {
            "GXT": "CLO_GRM_G_0_1",
            "Localized": "Brown Digital Armored"
        },
        "2": {
            "GXT": "CLO_GRM_G_0_2",
            "Localized": "Green Digital Armored"
        },
        "3": {
            "GXT": "CLO_GRM_G_0_3",
            "Localized": "Gray Digital Armored"
        },
        "4": {
            "GXT": "CLO_GRM_G_0_4",
            "Localized": "Peach Digital Armored"
        },
        "5": {
            "GXT": "CLO_GRM_G_0_5",
            "Localized": "Fall Armored"
        },
        "6": {
            "GXT": "CLO_GRM_G_0_6",
            "Localized": "Dark Woodland Armored"
        },
        "7": {
            "GXT": "CLO_GRM_G_0_7",
            "Localized": "Crosshatch Armored"
        },
        "8": {
            "GXT": "CLO_GRM_G_0_8",
            "Localized": "Moss Digital Armored"
        },
        "9": {
            "GXT": "CLO_GRM_G_0_9",
            "Localized": "Gray Woodland Armored"
        },
        "10": {
            "GXT": "CLO_GRM_G_0_10",
            "Localized": "Aqua Camo Armored"
        },
        "11": {
            "GXT": "CLO_GRM_G_0_11",
            "Localized": "Splinter Armored"
        },
        "12": {
            "GXT": "CLO_GRM_G_0_12",
            "Localized": "Contrast Camo Armored"
        },
        "13": {
            "GXT": "CLO_GRM_G_0_13",
            "Localized": "Cobble Armored"
        },
        "14": {
            "GXT": "CLO_GRM_G_0_14",
            "Localized": "Peach Camo Armored"
        },
        "15": {
            "GXT": "CLO_GRM_G_0_15",
            "Localized": "Brushstroke Armored"
        },
        "16": {
            "GXT": "CLO_GRM_G_0_16",
            "Localized": "Flecktarn Armored"
        },
        "17": {
            "GXT": "CLO_GRM_G_0_17",
            "Localized": "Light Woodland Armored"
        },
        "18": {
            "GXT": "CLO_GRM_G_0_18",
            "Localized": "Moss Armored"
        },
        "19": {
            "GXT": "CLO_GRM_G_0_19",
            "Localized": "Sand Armored"
        }
    },
    "145": {
        "0": {
            "GXT": "CLO_GRM_G_0_0",
            "Localized": "Blue Digital Armored"
        },
        "1": {
            "GXT": "CLO_GRM_G_0_1",
            "Localized": "Brown Digital Armored"
        },
        "2": {
            "GXT": "CLO_GRM_G_0_2",
            "Localized": "Green Digital Armored"
        },
        "3": {
            "GXT": "CLO_GRM_G_0_3",
            "Localized": "Gray Digital Armored"
        },
        "4": {
            "GXT": "CLO_GRM_G_0_4",
            "Localized": "Peach Digital Armored"
        },
        "5": {
            "GXT": "CLO_GRM_G_0_5",
            "Localized": "Fall Armored"
        },
        "6": {
            "GXT": "CLO_GRM_G_0_6",
            "Localized": "Dark Woodland Armored"
        },
        "7": {
            "GXT": "CLO_GRM_G_0_7",
            "Localized": "Crosshatch Armored"
        },
        "8": {
            "GXT": "CLO_GRM_G_0_8",
            "Localized": "Moss Digital Armored"
        },
        "9": {
            "GXT": "CLO_GRM_G_0_9",
            "Localized": "Gray Woodland Armored"
        },
        "10": {
            "GXT": "CLO_GRM_G_0_10",
            "Localized": "Aqua Camo Armored"
        },
        "11": {
            "GXT": "CLO_GRM_G_0_11",
            "Localized": "Splinter Armored"
        },
        "12": {
            "GXT": "CLO_GRM_G_0_12",
            "Localized": "Contrast Camo Armored"
        },
        "13": {
            "GXT": "CLO_GRM_G_0_13",
            "Localized": "Cobble Armored"
        },
        "14": {
            "GXT": "CLO_GRM_G_0_14",
            "Localized": "Peach Camo Armored"
        },
        "15": {
            "GXT": "CLO_GRM_G_0_15",
            "Localized": "Brushstroke Armored"
        },
        "16": {
            "GXT": "CLO_GRM_G_0_16",
            "Localized": "Flecktarn Armored"
        },
        "17": {
            "GXT": "CLO_GRM_G_0_17",
            "Localized": "Light Woodland Armored"
        },
        "18": {
            "GXT": "CLO_GRM_G_0_18",
            "Localized": "Moss Armored"
        },
        "19": {
            "GXT": "CLO_GRM_G_0_19",
            "Localized": "Sand Armored"
        }
    },
    "146": {
        "0": {
            "GXT": "CLO_GRM_G_0_0",
            "Localized": "Blue Digital Armored"
        },
        "1": {
            "GXT": "CLO_GRM_G_0_1",
            "Localized": "Brown Digital Armored"
        },
        "2": {
            "GXT": "CLO_GRM_G_0_2",
            "Localized": "Green Digital Armored"
        },
        "3": {
            "GXT": "CLO_GRM_G_0_3",
            "Localized": "Gray Digital Armored"
        },
        "4": {
            "GXT": "CLO_GRM_G_0_4",
            "Localized": "Peach Digital Armored"
        },
        "5": {
            "GXT": "CLO_GRM_G_0_5",
            "Localized": "Fall Armored"
        },
        "6": {
            "GXT": "CLO_GRM_G_0_6",
            "Localized": "Dark Woodland Armored"
        },
        "7": {
            "GXT": "CLO_GRM_G_0_7",
            "Localized": "Crosshatch Armored"
        },
        "8": {
            "GXT": "CLO_GRM_G_0_8",
            "Localized": "Moss Digital Armored"
        },
        "9": {
            "GXT": "CLO_GRM_G_0_9",
            "Localized": "Gray Woodland Armored"
        },
        "10": {
            "GXT": "CLO_GRM_G_0_10",
            "Localized": "Aqua Camo Armored"
        },
        "11": {
            "GXT": "CLO_GRM_G_0_11",
            "Localized": "Splinter Armored"
        },
        "12": {
            "GXT": "CLO_GRM_G_0_12",
            "Localized": "Contrast Camo Armored"
        },
        "13": {
            "GXT": "CLO_GRM_G_0_13",
            "Localized": "Cobble Armored"
        },
        "14": {
            "GXT": "CLO_GRM_G_0_14",
            "Localized": "Peach Camo Armored"
        },
        "15": {
            "GXT": "CLO_GRM_G_0_15",
            "Localized": "Brushstroke Armored"
        },
        "16": {
            "GXT": "CLO_GRM_G_0_16",
            "Localized": "Flecktarn Armored"
        },
        "17": {
            "GXT": "CLO_GRM_G_0_17",
            "Localized": "Light Woodland Armored"
        },
        "18": {
            "GXT": "CLO_GRM_G_0_18",
            "Localized": "Moss Armored"
        },
        "19": {
            "GXT": "CLO_GRM_G_0_19",
            "Localized": "Sand Armored"
        }
    },
    "147": {
        "0": {
            "GXT": "CLO_GRM_G_0_0",
            "Localized": "Blue Digital Armored"
        },
        "1": {
            "GXT": "CLO_GRM_G_0_1",
            "Localized": "Brown Digital Armored"
        },
        "2": {
            "GXT": "CLO_GRM_G_0_2",
            "Localized": "Green Digital Armored"
        },
        "3": {
            "GXT": "CLO_GRM_G_0_3",
            "Localized": "Gray Digital Armored"
        },
        "4": {
            "GXT": "CLO_GRM_G_0_4",
            "Localized": "Peach Digital Armored"
        },
        "5": {
            "GXT": "CLO_GRM_G_0_5",
            "Localized": "Fall Armored"
        },
        "6": {
            "GXT": "CLO_GRM_G_0_6",
            "Localized": "Dark Woodland Armored"
        },
        "7": {
            "GXT": "CLO_GRM_G_0_7",
            "Localized": "Crosshatch Armored"
        },
        "8": {
            "GXT": "CLO_GRM_G_0_8",
            "Localized": "Moss Digital Armored"
        },
        "9": {
            "GXT": "CLO_GRM_G_0_9",
            "Localized": "Gray Woodland Armored"
        },
        "10": {
            "GXT": "CLO_GRM_G_0_10",
            "Localized": "Aqua Camo Armored"
        },
        "11": {
            "GXT": "CLO_GRM_G_0_11",
            "Localized": "Splinter Armored"
        },
        "12": {
            "GXT": "CLO_GRM_G_0_12",
            "Localized": "Contrast Camo Armored"
        },
        "13": {
            "GXT": "CLO_GRM_G_0_13",
            "Localized": "Cobble Armored"
        },
        "14": {
            "GXT": "CLO_GRM_G_0_14",
            "Localized": "Peach Camo Armored"
        },
        "15": {
            "GXT": "CLO_GRM_G_0_15",
            "Localized": "Brushstroke Armored"
        },
        "16": {
            "GXT": "CLO_GRM_G_0_16",
            "Localized": "Flecktarn Armored"
        },
        "17": {
            "GXT": "CLO_GRM_G_0_17",
            "Localized": "Light Woodland Armored"
        },
        "18": {
            "GXT": "CLO_GRM_G_0_18",
            "Localized": "Moss Armored"
        },
        "19": {
            "GXT": "CLO_GRM_G_0_19",
            "Localized": "Sand Armored"
        }
    },
    "148": {
        "0": {
            "GXT": "CLO_GRM_G_0_0",
            "Localized": "Blue Digital Armored"
        },
        "1": {
            "GXT": "CLO_GRM_G_0_1",
            "Localized": "Brown Digital Armored"
        },
        "2": {
            "GXT": "CLO_GRM_G_0_2",
            "Localized": "Green Digital Armored"
        },
        "3": {
            "GXT": "CLO_GRM_G_0_3",
            "Localized": "Gray Digital Armored"
        },
        "4": {
            "GXT": "CLO_GRM_G_0_4",
            "Localized": "Peach Digital Armored"
        },
        "5": {
            "GXT": "CLO_GRM_G_0_5",
            "Localized": "Fall Armored"
        },
        "6": {
            "GXT": "CLO_GRM_G_0_6",
            "Localized": "Dark Woodland Armored"
        },
        "7": {
            "GXT": "CLO_GRM_G_0_7",
            "Localized": "Crosshatch Armored"
        },
        "8": {
            "GXT": "CLO_GRM_G_0_8",
            "Localized": "Moss Digital Armored"
        },
        "9": {
            "GXT": "CLO_GRM_G_0_9",
            "Localized": "Gray Woodland Armored"
        },
        "10": {
            "GXT": "CLO_GRM_G_0_10",
            "Localized": "Aqua Camo Armored"
        },
        "11": {
            "GXT": "CLO_GRM_G_0_11",
            "Localized": "Splinter Armored"
        },
        "12": {
            "GXT": "CLO_GRM_G_0_12",
            "Localized": "Contrast Camo Armored"
        },
        "13": {
            "GXT": "CLO_GRM_G_0_13",
            "Localized": "Cobble Armored"
        },
        "14": {
            "GXT": "CLO_GRM_G_0_14",
            "Localized": "Peach Camo Armored"
        },
        "15": {
            "GXT": "CLO_GRM_G_0_15",
            "Localized": "Brushstroke Armored"
        },
        "16": {
            "GXT": "CLO_GRM_G_0_16",
            "Localized": "Flecktarn Armored"
        },
        "17": {
            "GXT": "CLO_GRM_G_0_17",
            "Localized": "Light Woodland Armored"
        },
        "18": {
            "GXT": "CLO_GRM_G_0_18",
            "Localized": "Moss Armored"
        },
        "19": {
            "GXT": "CLO_GRM_G_0_19",
            "Localized": "Sand Armored"
        }
    },
    "149": {
        "0": {
            "GXT": "CLO_GRM_G_0_0",
            "Localized": "Blue Digital Armored"
        },
        "1": {
            "GXT": "CLO_GRM_G_0_1",
            "Localized": "Brown Digital Armored"
        },
        "2": {
            "GXT": "CLO_GRM_G_0_2",
            "Localized": "Green Digital Armored"
        },
        "3": {
            "GXT": "CLO_GRM_G_0_3",
            "Localized": "Gray Digital Armored"
        },
        "4": {
            "GXT": "CLO_GRM_G_0_4",
            "Localized": "Peach Digital Armored"
        },
        "5": {
            "GXT": "CLO_GRM_G_0_5",
            "Localized": "Fall Armored"
        },
        "6": {
            "GXT": "CLO_GRM_G_0_6",
            "Localized": "Dark Woodland Armored"
        },
        "7": {
            "GXT": "CLO_GRM_G_0_7",
            "Localized": "Crosshatch Armored"
        },
        "8": {
            "GXT": "CLO_GRM_G_0_8",
            "Localized": "Moss Digital Armored"
        },
        "9": {
            "GXT": "CLO_GRM_G_0_9",
            "Localized": "Gray Woodland Armored"
        },
        "10": {
            "GXT": "CLO_GRM_G_0_10",
            "Localized": "Aqua Camo Armored"
        },
        "11": {
            "GXT": "CLO_GRM_G_0_11",
            "Localized": "Splinter Armored"
        },
        "12": {
            "GXT": "CLO_GRM_G_0_12",
            "Localized": "Contrast Camo Armored"
        },
        "13": {
            "GXT": "CLO_GRM_G_0_13",
            "Localized": "Cobble Armored"
        },
        "14": {
            "GXT": "CLO_GRM_G_0_14",
            "Localized": "Peach Camo Armored"
        },
        "15": {
            "GXT": "CLO_GRM_G_0_15",
            "Localized": "Brushstroke Armored"
        },
        "16": {
            "GXT": "CLO_GRM_G_0_16",
            "Localized": "Flecktarn Armored"
        },
        "17": {
            "GXT": "CLO_GRM_G_0_17",
            "Localized": "Light Woodland Armored"
        },
        "18": {
            "GXT": "CLO_GRM_G_0_18",
            "Localized": "Moss Armored"
        },
        "19": {
            "GXT": "CLO_GRM_G_0_19",
            "Localized": "Sand Armored"
        }
    },
    "150": {
        "0": {
            "GXT": "CLO_GRM_G_0_0",
            "Localized": "Blue Digital Armored"
        },
        "1": {
            "GXT": "CLO_GRM_G_0_1",
            "Localized": "Brown Digital Armored"
        },
        "2": {
            "GXT": "CLO_GRM_G_0_2",
            "Localized": "Green Digital Armored"
        },
        "3": {
            "GXT": "CLO_GRM_G_0_3",
            "Localized": "Gray Digital Armored"
        },
        "4": {
            "GXT": "CLO_GRM_G_0_4",
            "Localized": "Peach Digital Armored"
        },
        "5": {
            "GXT": "CLO_GRM_G_0_5",
            "Localized": "Fall Armored"
        },
        "6": {
            "GXT": "CLO_GRM_G_0_6",
            "Localized": "Dark Woodland Armored"
        },
        "7": {
            "GXT": "CLO_GRM_G_0_7",
            "Localized": "Crosshatch Armored"
        },
        "8": {
            "GXT": "CLO_GRM_G_0_8",
            "Localized": "Moss Digital Armored"
        },
        "9": {
            "GXT": "CLO_GRM_G_0_9",
            "Localized": "Gray Woodland Armored"
        },
        "10": {
            "GXT": "CLO_GRM_G_0_10",
            "Localized": "Aqua Camo Armored"
        },
        "11": {
            "GXT": "CLO_GRM_G_0_11",
            "Localized": "Splinter Armored"
        },
        "12": {
            "GXT": "CLO_GRM_G_0_12",
            "Localized": "Contrast Camo Armored"
        },
        "13": {
            "GXT": "CLO_GRM_G_0_13",
            "Localized": "Cobble Armored"
        },
        "14": {
            "GXT": "CLO_GRM_G_0_14",
            "Localized": "Peach Camo Armored"
        },
        "15": {
            "GXT": "CLO_GRM_G_0_15",
            "Localized": "Brushstroke Armored"
        },
        "16": {
            "GXT": "CLO_GRM_G_0_16",
            "Localized": "Flecktarn Armored"
        },
        "17": {
            "GXT": "CLO_GRM_G_0_17",
            "Localized": "Light Woodland Armored"
        },
        "18": {
            "GXT": "CLO_GRM_G_0_18",
            "Localized": "Moss Armored"
        },
        "19": {
            "GXT": "CLO_GRM_G_0_19",
            "Localized": "Sand Armored"
        }
    },
    "151": {
        "0": {
            "GXT": "CLO_GRM_G_1_0",
            "Localized": "Blue Digital Tactical"
        },
        "1": {
            "GXT": "CLO_GRM_G_1_1",
            "Localized": "Brown Digital Tactical"
        },
        "2": {
            "GXT": "CLO_GRM_G_1_2",
            "Localized": "Green Digital Tactical"
        },
        "3": {
            "GXT": "CLO_GRM_G_1_3",
            "Localized": "Gray Digital Tactical"
        },
        "4": {
            "GXT": "CLO_GRM_G_1_4",
            "Localized": "Peach Digital Tactical"
        },
        "5": {
            "GXT": "CLO_GRM_G_1_5",
            "Localized": "Fall Tactical"
        },
        "6": {
            "GXT": "CLO_GRM_G_1_6",
            "Localized": "Dark Woodland Tactical"
        },
        "7": {
            "GXT": "CLO_GRM_G_1_7",
            "Localized": "Crosshatch Tactical"
        },
        "8": {
            "GXT": "CLO_GRM_G_1_8",
            "Localized": "Moss Digital Tactical"
        },
        "9": {
            "GXT": "CLO_GRM_G_1_9",
            "Localized": "Gray Woodland Tactical"
        },
        "10": {
            "GXT": "CLO_GRM_G_1_10",
            "Localized": "Aqua Camo Tactical"
        },
        "11": {
            "GXT": "CLO_GRM_G_1_11",
            "Localized": "Splinter Tactical"
        },
        "12": {
            "GXT": "CLO_GRM_G_1_12",
            "Localized": "Contrast Camo Tactical"
        },
        "13": {
            "GXT": "CLO_GRM_G_1_13",
            "Localized": "Cobble Tactical"
        },
        "14": {
            "GXT": "CLO_GRM_G_1_14",
            "Localized": "Peach Camo Tactical"
        },
        "15": {
            "GXT": "CLO_GRM_G_1_15",
            "Localized": "Brushstroke Tactical"
        },
        "16": {
            "GXT": "CLO_GRM_G_1_16",
            "Localized": "Flecktarn Tactical"
        },
        "17": {
            "GXT": "CLO_GRM_G_1_17",
            "Localized": "Light Woodland Tactical"
        },
        "18": {
            "GXT": "CLO_GRM_G_1_18",
            "Localized": "Moss Tactical"
        },
        "19": {
            "GXT": "CLO_GRM_G_1_19",
            "Localized": "Sand Tactical"
        }
    },
    "152": {
        "0": {
            "GXT": "CLO_GRM_G_1_0",
            "Localized": "Blue Digital Tactical"
        },
        "1": {
            "GXT": "CLO_GRM_G_1_1",
            "Localized": "Brown Digital Tactical"
        },
        "2": {
            "GXT": "CLO_GRM_G_1_2",
            "Localized": "Green Digital Tactical"
        },
        "3": {
            "GXT": "CLO_GRM_G_1_3",
            "Localized": "Gray Digital Tactical"
        },
        "4": {
            "GXT": "CLO_GRM_G_1_4",
            "Localized": "Peach Digital Tactical"
        },
        "5": {
            "GXT": "CLO_GRM_G_1_5",
            "Localized": "Fall Tactical"
        },
        "6": {
            "GXT": "CLO_GRM_G_1_6",
            "Localized": "Dark Woodland Tactical"
        },
        "7": {
            "GXT": "CLO_GRM_G_1_7",
            "Localized": "Crosshatch Tactical"
        },
        "8": {
            "GXT": "CLO_GRM_G_1_8",
            "Localized": "Moss Digital Tactical"
        },
        "9": {
            "GXT": "CLO_GRM_G_1_9",
            "Localized": "Gray Woodland Tactical"
        },
        "10": {
            "GXT": "CLO_GRM_G_1_10",
            "Localized": "Aqua Camo Tactical"
        },
        "11": {
            "GXT": "CLO_GRM_G_1_11",
            "Localized": "Splinter Tactical"
        },
        "12": {
            "GXT": "CLO_GRM_G_1_12",
            "Localized": "Contrast Camo Tactical"
        },
        "13": {
            "GXT": "CLO_GRM_G_1_13",
            "Localized": "Cobble Tactical"
        },
        "14": {
            "GXT": "CLO_GRM_G_1_14",
            "Localized": "Peach Camo Tactical"
        },
        "15": {
            "GXT": "CLO_GRM_G_1_15",
            "Localized": "Brushstroke Tactical"
        },
        "16": {
            "GXT": "CLO_GRM_G_1_16",
            "Localized": "Flecktarn Tactical"
        },
        "17": {
            "GXT": "CLO_GRM_G_1_17",
            "Localized": "Light Woodland Tactical"
        },
        "18": {
            "GXT": "CLO_GRM_G_1_18",
            "Localized": "Moss Tactical"
        },
        "19": {
            "GXT": "CLO_GRM_G_1_19",
            "Localized": "Sand Tactical"
        }
    },
    "153": {
        "0": {
            "GXT": "CLO_GRM_G_1_0",
            "Localized": "Blue Digital Tactical"
        },
        "1": {
            "GXT": "CLO_GRM_G_1_1",
            "Localized": "Brown Digital Tactical"
        },
        "2": {
            "GXT": "CLO_GRM_G_1_2",
            "Localized": "Green Digital Tactical"
        },
        "3": {
            "GXT": "CLO_GRM_G_1_3",
            "Localized": "Gray Digital Tactical"
        },
        "4": {
            "GXT": "CLO_GRM_G_1_4",
            "Localized": "Peach Digital Tactical"
        },
        "5": {
            "GXT": "CLO_GRM_G_1_5",
            "Localized": "Fall Tactical"
        },
        "6": {
            "GXT": "CLO_GRM_G_1_6",
            "Localized": "Dark Woodland Tactical"
        },
        "7": {
            "GXT": "CLO_GRM_G_1_7",
            "Localized": "Crosshatch Tactical"
        },
        "8": {
            "GXT": "CLO_GRM_G_1_8",
            "Localized": "Moss Digital Tactical"
        },
        "9": {
            "GXT": "CLO_GRM_G_1_9",
            "Localized": "Gray Woodland Tactical"
        },
        "10": {
            "GXT": "CLO_GRM_G_1_10",
            "Localized": "Aqua Camo Tactical"
        },
        "11": {
            "GXT": "CLO_GRM_G_1_11",
            "Localized": "Splinter Tactical"
        },
        "12": {
            "GXT": "CLO_GRM_G_1_12",
            "Localized": "Contrast Camo Tactical"
        },
        "13": {
            "GXT": "CLO_GRM_G_1_13",
            "Localized": "Cobble Tactical"
        },
        "14": {
            "GXT": "CLO_GRM_G_1_14",
            "Localized": "Peach Camo Tactical"
        },
        "15": {
            "GXT": "CLO_GRM_G_1_15",
            "Localized": "Brushstroke Tactical"
        },
        "16": {
            "GXT": "CLO_GRM_G_1_16",
            "Localized": "Flecktarn Tactical"
        },
        "17": {
            "GXT": "CLO_GRM_G_1_17",
            "Localized": "Light Woodland Tactical"
        },
        "18": {
            "GXT": "CLO_GRM_G_1_18",
            "Localized": "Moss Tactical"
        },
        "19": {
            "GXT": "CLO_GRM_G_1_19",
            "Localized": "Sand Tactical"
        }
    },
    "154": {
        "0": {
            "GXT": "CLO_GRM_G_1_0",
            "Localized": "Blue Digital Tactical"
        },
        "1": {
            "GXT": "CLO_GRM_G_1_1",
            "Localized": "Brown Digital Tactical"
        },
        "2": {
            "GXT": "CLO_GRM_G_1_2",
            "Localized": "Green Digital Tactical"
        },
        "3": {
            "GXT": "CLO_GRM_G_1_3",
            "Localized": "Gray Digital Tactical"
        },
        "4": {
            "GXT": "CLO_GRM_G_1_4",
            "Localized": "Peach Digital Tactical"
        },
        "5": {
            "GXT": "CLO_GRM_G_1_5",
            "Localized": "Fall Tactical"
        },
        "6": {
            "GXT": "CLO_GRM_G_1_6",
            "Localized": "Dark Woodland Tactical"
        },
        "7": {
            "GXT": "CLO_GRM_G_1_7",
            "Localized": "Crosshatch Tactical"
        },
        "8": {
            "GXT": "CLO_GRM_G_1_8",
            "Localized": "Moss Digital Tactical"
        },
        "9": {
            "GXT": "CLO_GRM_G_1_9",
            "Localized": "Gray Woodland Tactical"
        },
        "10": {
            "GXT": "CLO_GRM_G_1_10",
            "Localized": "Aqua Camo Tactical"
        },
        "11": {
            "GXT": "CLO_GRM_G_1_11",
            "Localized": "Splinter Tactical"
        },
        "12": {
            "GXT": "CLO_GRM_G_1_12",
            "Localized": "Contrast Camo Tactical"
        },
        "13": {
            "GXT": "CLO_GRM_G_1_13",
            "Localized": "Cobble Tactical"
        },
        "14": {
            "GXT": "CLO_GRM_G_1_14",
            "Localized": "Peach Camo Tactical"
        },
        "15": {
            "GXT": "CLO_GRM_G_1_15",
            "Localized": "Brushstroke Tactical"
        },
        "16": {
            "GXT": "CLO_GRM_G_1_16",
            "Localized": "Flecktarn Tactical"
        },
        "17": {
            "GXT": "CLO_GRM_G_1_17",
            "Localized": "Light Woodland Tactical"
        },
        "18": {
            "GXT": "CLO_GRM_G_1_18",
            "Localized": "Moss Tactical"
        },
        "19": {
            "GXT": "CLO_GRM_G_1_19",
            "Localized": "Sand Tactical"
        }
    },
    "155": {
        "0": {
            "GXT": "CLO_GRM_G_1_0",
            "Localized": "Blue Digital Tactical"
        },
        "1": {
            "GXT": "CLO_GRM_G_1_1",
            "Localized": "Brown Digital Tactical"
        },
        "2": {
            "GXT": "CLO_GRM_G_1_2",
            "Localized": "Green Digital Tactical"
        },
        "3": {
            "GXT": "CLO_GRM_G_1_3",
            "Localized": "Gray Digital Tactical"
        },
        "4": {
            "GXT": "CLO_GRM_G_1_4",
            "Localized": "Peach Digital Tactical"
        },
        "5": {
            "GXT": "CLO_GRM_G_1_5",
            "Localized": "Fall Tactical"
        },
        "6": {
            "GXT": "CLO_GRM_G_1_6",
            "Localized": "Dark Woodland Tactical"
        },
        "7": {
            "GXT": "CLO_GRM_G_1_7",
            "Localized": "Crosshatch Tactical"
        },
        "8": {
            "GXT": "CLO_GRM_G_1_8",
            "Localized": "Moss Digital Tactical"
        },
        "9": {
            "GXT": "CLO_GRM_G_1_9",
            "Localized": "Gray Woodland Tactical"
        },
        "10": {
            "GXT": "CLO_GRM_G_1_10",
            "Localized": "Aqua Camo Tactical"
        },
        "11": {
            "GXT": "CLO_GRM_G_1_11",
            "Localized": "Splinter Tactical"
        },
        "12": {
            "GXT": "CLO_GRM_G_1_12",
            "Localized": "Contrast Camo Tactical"
        },
        "13": {
            "GXT": "CLO_GRM_G_1_13",
            "Localized": "Cobble Tactical"
        },
        "14": {
            "GXT": "CLO_GRM_G_1_14",
            "Localized": "Peach Camo Tactical"
        },
        "15": {
            "GXT": "CLO_GRM_G_1_15",
            "Localized": "Brushstroke Tactical"
        },
        "16": {
            "GXT": "CLO_GRM_G_1_16",
            "Localized": "Flecktarn Tactical"
        },
        "17": {
            "GXT": "CLO_GRM_G_1_17",
            "Localized": "Light Woodland Tactical"
        },
        "18": {
            "GXT": "CLO_GRM_G_1_18",
            "Localized": "Moss Tactical"
        },
        "19": {
            "GXT": "CLO_GRM_G_1_19",
            "Localized": "Sand Tactical"
        }
    },
    "156": {
        "0": {
            "GXT": "CLO_GRM_G_1_0",
            "Localized": "Blue Digital Tactical"
        },
        "1": {
            "GXT": "CLO_GRM_G_1_1",
            "Localized": "Brown Digital Tactical"
        },
        "2": {
            "GXT": "CLO_GRM_G_1_2",
            "Localized": "Green Digital Tactical"
        },
        "3": {
            "GXT": "CLO_GRM_G_1_3",
            "Localized": "Gray Digital Tactical"
        },
        "4": {
            "GXT": "CLO_GRM_G_1_4",
            "Localized": "Peach Digital Tactical"
        },
        "5": {
            "GXT": "CLO_GRM_G_1_5",
            "Localized": "Fall Tactical"
        },
        "6": {
            "GXT": "CLO_GRM_G_1_6",
            "Localized": "Dark Woodland Tactical"
        },
        "7": {
            "GXT": "CLO_GRM_G_1_7",
            "Localized": "Crosshatch Tactical"
        },
        "8": {
            "GXT": "CLO_GRM_G_1_8",
            "Localized": "Moss Digital Tactical"
        },
        "9": {
            "GXT": "CLO_GRM_G_1_9",
            "Localized": "Gray Woodland Tactical"
        },
        "10": {
            "GXT": "CLO_GRM_G_1_10",
            "Localized": "Aqua Camo Tactical"
        },
        "11": {
            "GXT": "CLO_GRM_G_1_11",
            "Localized": "Splinter Tactical"
        },
        "12": {
            "GXT": "CLO_GRM_G_1_12",
            "Localized": "Contrast Camo Tactical"
        },
        "13": {
            "GXT": "CLO_GRM_G_1_13",
            "Localized": "Cobble Tactical"
        },
        "14": {
            "GXT": "CLO_GRM_G_1_14",
            "Localized": "Peach Camo Tactical"
        },
        "15": {
            "GXT": "CLO_GRM_G_1_15",
            "Localized": "Brushstroke Tactical"
        },
        "16": {
            "GXT": "CLO_GRM_G_1_16",
            "Localized": "Flecktarn Tactical"
        },
        "17": {
            "GXT": "CLO_GRM_G_1_17",
            "Localized": "Light Woodland Tactical"
        },
        "18": {
            "GXT": "CLO_GRM_G_1_18",
            "Localized": "Moss Tactical"
        },
        "19": {
            "GXT": "CLO_GRM_G_1_19",
            "Localized": "Sand Tactical"
        }
    },
    "157": {
        "0": {
            "GXT": "CLO_GRM_G_1_0",
            "Localized": "Blue Digital Tactical"
        },
        "1": {
            "GXT": "CLO_GRM_G_1_1",
            "Localized": "Brown Digital Tactical"
        },
        "2": {
            "GXT": "CLO_GRM_G_1_2",
            "Localized": "Green Digital Tactical"
        },
        "3": {
            "GXT": "CLO_GRM_G_1_3",
            "Localized": "Gray Digital Tactical"
        },
        "4": {
            "GXT": "CLO_GRM_G_1_4",
            "Localized": "Peach Digital Tactical"
        },
        "5": {
            "GXT": "CLO_GRM_G_1_5",
            "Localized": "Fall Tactical"
        },
        "6": {
            "GXT": "CLO_GRM_G_1_6",
            "Localized": "Dark Woodland Tactical"
        },
        "7": {
            "GXT": "CLO_GRM_G_1_7",
            "Localized": "Crosshatch Tactical"
        },
        "8": {
            "GXT": "CLO_GRM_G_1_8",
            "Localized": "Moss Digital Tactical"
        },
        "9": {
            "GXT": "CLO_GRM_G_1_9",
            "Localized": "Gray Woodland Tactical"
        },
        "10": {
            "GXT": "CLO_GRM_G_1_10",
            "Localized": "Aqua Camo Tactical"
        },
        "11": {
            "GXT": "CLO_GRM_G_1_11",
            "Localized": "Splinter Tactical"
        },
        "12": {
            "GXT": "CLO_GRM_G_1_12",
            "Localized": "Contrast Camo Tactical"
        },
        "13": {
            "GXT": "CLO_GRM_G_1_13",
            "Localized": "Cobble Tactical"
        },
        "14": {
            "GXT": "CLO_GRM_G_1_14",
            "Localized": "Peach Camo Tactical"
        },
        "15": {
            "GXT": "CLO_GRM_G_1_15",
            "Localized": "Brushstroke Tactical"
        },
        "16": {
            "GXT": "CLO_GRM_G_1_16",
            "Localized": "Flecktarn Tactical"
        },
        "17": {
            "GXT": "CLO_GRM_G_1_17",
            "Localized": "Light Woodland Tactical"
        },
        "18": {
            "GXT": "CLO_GRM_G_1_18",
            "Localized": "Moss Tactical"
        },
        "19": {
            "GXT": "CLO_GRM_G_1_19",
            "Localized": "Sand Tactical"
        }
    },
    "158": {
        "0": {
            "GXT": "CLO_GRM_G_1_0",
            "Localized": "Blue Digital Tactical"
        },
        "1": {
            "GXT": "CLO_GRM_G_1_1",
            "Localized": "Brown Digital Tactical"
        },
        "2": {
            "GXT": "CLO_GRM_G_1_2",
            "Localized": "Green Digital Tactical"
        },
        "3": {
            "GXT": "CLO_GRM_G_1_3",
            "Localized": "Gray Digital Tactical"
        },
        "4": {
            "GXT": "CLO_GRM_G_1_4",
            "Localized": "Peach Digital Tactical"
        },
        "5": {
            "GXT": "CLO_GRM_G_1_5",
            "Localized": "Fall Tactical"
        },
        "6": {
            "GXT": "CLO_GRM_G_1_6",
            "Localized": "Dark Woodland Tactical"
        },
        "7": {
            "GXT": "CLO_GRM_G_1_7",
            "Localized": "Crosshatch Tactical"
        },
        "8": {
            "GXT": "CLO_GRM_G_1_8",
            "Localized": "Moss Digital Tactical"
        },
        "9": {
            "GXT": "CLO_GRM_G_1_9",
            "Localized": "Gray Woodland Tactical"
        },
        "10": {
            "GXT": "CLO_GRM_G_1_10",
            "Localized": "Aqua Camo Tactical"
        },
        "11": {
            "GXT": "CLO_GRM_G_1_11",
            "Localized": "Splinter Tactical"
        },
        "12": {
            "GXT": "CLO_GRM_G_1_12",
            "Localized": "Contrast Camo Tactical"
        },
        "13": {
            "GXT": "CLO_GRM_G_1_13",
            "Localized": "Cobble Tactical"
        },
        "14": {
            "GXT": "CLO_GRM_G_1_14",
            "Localized": "Peach Camo Tactical"
        },
        "15": {
            "GXT": "CLO_GRM_G_1_15",
            "Localized": "Brushstroke Tactical"
        },
        "16": {
            "GXT": "CLO_GRM_G_1_16",
            "Localized": "Flecktarn Tactical"
        },
        "17": {
            "GXT": "CLO_GRM_G_1_17",
            "Localized": "Light Woodland Tactical"
        },
        "18": {
            "GXT": "CLO_GRM_G_1_18",
            "Localized": "Moss Tactical"
        },
        "19": {
            "GXT": "CLO_GRM_G_1_19",
            "Localized": "Sand Tactical"
        }
    },
    "159": {
        "0": {
            "GXT": "CLO_GRM_G_1_0",
            "Localized": "Blue Digital Tactical"
        },
        "1": {
            "GXT": "CLO_GRM_G_1_1",
            "Localized": "Brown Digital Tactical"
        },
        "2": {
            "GXT": "CLO_GRM_G_1_2",
            "Localized": "Green Digital Tactical"
        },
        "3": {
            "GXT": "CLO_GRM_G_1_3",
            "Localized": "Gray Digital Tactical"
        },
        "4": {
            "GXT": "CLO_GRM_G_1_4",
            "Localized": "Peach Digital Tactical"
        },
        "5": {
            "GXT": "CLO_GRM_G_1_5",
            "Localized": "Fall Tactical"
        },
        "6": {
            "GXT": "CLO_GRM_G_1_6",
            "Localized": "Dark Woodland Tactical"
        },
        "7": {
            "GXT": "CLO_GRM_G_1_7",
            "Localized": "Crosshatch Tactical"
        },
        "8": {
            "GXT": "CLO_GRM_G_1_8",
            "Localized": "Moss Digital Tactical"
        },
        "9": {
            "GXT": "CLO_GRM_G_1_9",
            "Localized": "Gray Woodland Tactical"
        },
        "10": {
            "GXT": "CLO_GRM_G_1_10",
            "Localized": "Aqua Camo Tactical"
        },
        "11": {
            "GXT": "CLO_GRM_G_1_11",
            "Localized": "Splinter Tactical"
        },
        "12": {
            "GXT": "CLO_GRM_G_1_12",
            "Localized": "Contrast Camo Tactical"
        },
        "13": {
            "GXT": "CLO_GRM_G_1_13",
            "Localized": "Cobble Tactical"
        },
        "14": {
            "GXT": "CLO_GRM_G_1_14",
            "Localized": "Peach Camo Tactical"
        },
        "15": {
            "GXT": "CLO_GRM_G_1_15",
            "Localized": "Brushstroke Tactical"
        },
        "16": {
            "GXT": "CLO_GRM_G_1_16",
            "Localized": "Flecktarn Tactical"
        },
        "17": {
            "GXT": "CLO_GRM_G_1_17",
            "Localized": "Light Woodland Tactical"
        },
        "18": {
            "GXT": "CLO_GRM_G_1_18",
            "Localized": "Moss Tactical"
        },
        "19": {
            "GXT": "CLO_GRM_G_1_19",
            "Localized": "Sand Tactical"
        }
    },
    "160": {
        "0": {
            "GXT": "CLO_GRM_G_1_0",
            "Localized": "Blue Digital Tactical"
        },
        "1": {
            "GXT": "CLO_GRM_G_1_1",
            "Localized": "Brown Digital Tactical"
        },
        "2": {
            "GXT": "CLO_GRM_G_1_2",
            "Localized": "Green Digital Tactical"
        },
        "3": {
            "GXT": "CLO_GRM_G_1_3",
            "Localized": "Gray Digital Tactical"
        },
        "4": {
            "GXT": "CLO_GRM_G_1_4",
            "Localized": "Peach Digital Tactical"
        },
        "5": {
            "GXT": "CLO_GRM_G_1_5",
            "Localized": "Fall Tactical"
        },
        "6": {
            "GXT": "CLO_GRM_G_1_6",
            "Localized": "Dark Woodland Tactical"
        },
        "7": {
            "GXT": "CLO_GRM_G_1_7",
            "Localized": "Crosshatch Tactical"
        },
        "8": {
            "GXT": "CLO_GRM_G_1_8",
            "Localized": "Moss Digital Tactical"
        },
        "9": {
            "GXT": "CLO_GRM_G_1_9",
            "Localized": "Gray Woodland Tactical"
        },
        "10": {
            "GXT": "CLO_GRM_G_1_10",
            "Localized": "Aqua Camo Tactical"
        },
        "11": {
            "GXT": "CLO_GRM_G_1_11",
            "Localized": "Splinter Tactical"
        },
        "12": {
            "GXT": "CLO_GRM_G_1_12",
            "Localized": "Contrast Camo Tactical"
        },
        "13": {
            "GXT": "CLO_GRM_G_1_13",
            "Localized": "Cobble Tactical"
        },
        "14": {
            "GXT": "CLO_GRM_G_1_14",
            "Localized": "Peach Camo Tactical"
        },
        "15": {
            "GXT": "CLO_GRM_G_1_15",
            "Localized": "Brushstroke Tactical"
        },
        "16": {
            "GXT": "CLO_GRM_G_1_16",
            "Localized": "Flecktarn Tactical"
        },
        "17": {
            "GXT": "CLO_GRM_G_1_17",
            "Localized": "Light Woodland Tactical"
        },
        "18": {
            "GXT": "CLO_GRM_G_1_18",
            "Localized": "Moss Tactical"
        },
        "19": {
            "GXT": "CLO_GRM_G_1_19",
            "Localized": "Sand Tactical"
        }
    },
    "161": {
        "0": {
            "GXT": "CLO_GRM_G_1_0",
            "Localized": "Blue Digital Tactical"
        },
        "1": {
            "GXT": "CLO_GRM_G_1_1",
            "Localized": "Brown Digital Tactical"
        },
        "2": {
            "GXT": "CLO_GRM_G_1_2",
            "Localized": "Green Digital Tactical"
        },
        "3": {
            "GXT": "CLO_GRM_G_1_3",
            "Localized": "Gray Digital Tactical"
        },
        "4": {
            "GXT": "CLO_GRM_G_1_4",
            "Localized": "Peach Digital Tactical"
        },
        "5": {
            "GXT": "CLO_GRM_G_1_5",
            "Localized": "Fall Tactical"
        },
        "6": {
            "GXT": "CLO_GRM_G_1_6",
            "Localized": "Dark Woodland Tactical"
        },
        "7": {
            "GXT": "CLO_GRM_G_1_7",
            "Localized": "Crosshatch Tactical"
        },
        "8": {
            "GXT": "CLO_GRM_G_1_8",
            "Localized": "Moss Digital Tactical"
        },
        "9": {
            "GXT": "CLO_GRM_G_1_9",
            "Localized": "Gray Woodland Tactical"
        },
        "10": {
            "GXT": "CLO_GRM_G_1_10",
            "Localized": "Aqua Camo Tactical"
        },
        "11": {
            "GXT": "CLO_GRM_G_1_11",
            "Localized": "Splinter Tactical"
        },
        "12": {
            "GXT": "CLO_GRM_G_1_12",
            "Localized": "Contrast Camo Tactical"
        },
        "13": {
            "GXT": "CLO_GRM_G_1_13",
            "Localized": "Cobble Tactical"
        },
        "14": {
            "GXT": "CLO_GRM_G_1_14",
            "Localized": "Peach Camo Tactical"
        },
        "15": {
            "GXT": "CLO_GRM_G_1_15",
            "Localized": "Brushstroke Tactical"
        },
        "16": {
            "GXT": "CLO_GRM_G_1_16",
            "Localized": "Flecktarn Tactical"
        },
        "17": {
            "GXT": "CLO_GRM_G_1_17",
            "Localized": "Light Woodland Tactical"
        },
        "18": {
            "GXT": "CLO_GRM_G_1_18",
            "Localized": "Moss Tactical"
        },
        "19": {
            "GXT": "CLO_GRM_G_1_19",
            "Localized": "Sand Tactical"
        }
    },
    "162": {
        "0": {
            "GXT": "CLO_GRM_G_1_0",
            "Localized": "Blue Digital Tactical"
        },
        "1": {
            "GXT": "CLO_GRM_G_1_1",
            "Localized": "Brown Digital Tactical"
        },
        "2": {
            "GXT": "CLO_GRM_G_1_2",
            "Localized": "Green Digital Tactical"
        },
        "3": {
            "GXT": "CLO_GRM_G_1_3",
            "Localized": "Gray Digital Tactical"
        },
        "4": {
            "GXT": "CLO_GRM_G_1_4",
            "Localized": "Peach Digital Tactical"
        },
        "5": {
            "GXT": "CLO_GRM_G_1_5",
            "Localized": "Fall Tactical"
        },
        "6": {
            "GXT": "CLO_GRM_G_1_6",
            "Localized": "Dark Woodland Tactical"
        },
        "7": {
            "GXT": "CLO_GRM_G_1_7",
            "Localized": "Crosshatch Tactical"
        },
        "8": {
            "GXT": "CLO_GRM_G_1_8",
            "Localized": "Moss Digital Tactical"
        },
        "9": {
            "GXT": "CLO_GRM_G_1_9",
            "Localized": "Gray Woodland Tactical"
        },
        "10": {
            "GXT": "CLO_GRM_G_1_10",
            "Localized": "Aqua Camo Tactical"
        },
        "11": {
            "GXT": "CLO_GRM_G_1_11",
            "Localized": "Splinter Tactical"
        },
        "12": {
            "GXT": "CLO_GRM_G_1_12",
            "Localized": "Contrast Camo Tactical"
        },
        "13": {
            "GXT": "CLO_GRM_G_1_13",
            "Localized": "Cobble Tactical"
        },
        "14": {
            "GXT": "CLO_GRM_G_1_14",
            "Localized": "Peach Camo Tactical"
        },
        "15": {
            "GXT": "CLO_GRM_G_1_15",
            "Localized": "Brushstroke Tactical"
        },
        "16": {
            "GXT": "CLO_GRM_G_1_16",
            "Localized": "Flecktarn Tactical"
        },
        "17": {
            "GXT": "CLO_GRM_G_1_17",
            "Localized": "Light Woodland Tactical"
        },
        "18": {
            "GXT": "CLO_GRM_G_1_18",
            "Localized": "Moss Tactical"
        },
        "19": {
            "GXT": "CLO_GRM_G_1_19",
            "Localized": "Sand Tactical"
        }
    },
    "163": {
        "0": {
            "GXT": "CLO_GRM_G_1_0",
            "Localized": "Blue Digital Tactical"
        },
        "1": {
            "GXT": "CLO_GRM_G_1_1",
            "Localized": "Brown Digital Tactical"
        },
        "2": {
            "GXT": "CLO_GRM_G_1_2",
            "Localized": "Green Digital Tactical"
        },
        "3": {
            "GXT": "CLO_GRM_G_1_3",
            "Localized": "Gray Digital Tactical"
        },
        "4": {
            "GXT": "CLO_GRM_G_1_4",
            "Localized": "Peach Digital Tactical"
        },
        "5": {
            "GXT": "CLO_GRM_G_1_5",
            "Localized": "Fall Tactical"
        },
        "6": {
            "GXT": "CLO_GRM_G_1_6",
            "Localized": "Dark Woodland Tactical"
        },
        "7": {
            "GXT": "CLO_GRM_G_1_7",
            "Localized": "Crosshatch Tactical"
        },
        "8": {
            "GXT": "CLO_GRM_G_1_8",
            "Localized": "Moss Digital Tactical"
        },
        "9": {
            "GXT": "CLO_GRM_G_1_9",
            "Localized": "Gray Woodland Tactical"
        },
        "10": {
            "GXT": "CLO_GRM_G_1_10",
            "Localized": "Aqua Camo Tactical"
        },
        "11": {
            "GXT": "CLO_GRM_G_1_11",
            "Localized": "Splinter Tactical"
        },
        "12": {
            "GXT": "CLO_GRM_G_1_12",
            "Localized": "Contrast Camo Tactical"
        },
        "13": {
            "GXT": "CLO_GRM_G_1_13",
            "Localized": "Cobble Tactical"
        },
        "14": {
            "GXT": "CLO_GRM_G_1_14",
            "Localized": "Peach Camo Tactical"
        },
        "15": {
            "GXT": "CLO_GRM_G_1_15",
            "Localized": "Brushstroke Tactical"
        },
        "16": {
            "GXT": "CLO_GRM_G_1_16",
            "Localized": "Flecktarn Tactical"
        },
        "17": {
            "GXT": "CLO_GRM_G_1_17",
            "Localized": "Light Woodland Tactical"
        },
        "18": {
            "GXT": "CLO_GRM_G_1_18",
            "Localized": "Moss Tactical"
        },
        "19": {
            "GXT": "CLO_GRM_G_1_19",
            "Localized": "Sand Tactical"
        }
    },
    "164": {
        "0": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "1": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "2": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "3": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "4": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "5": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "6": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "7": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "8": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "9": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "10": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "11": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        }
    },
    "165": {
        "0": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "1": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "2": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "3": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "4": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "5": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "6": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "7": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "8": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "9": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "10": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "11": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "12": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "13": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "14": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "15": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "16": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "17": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        }
    },
    "166": {
        "0": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "1": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "2": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "3": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "4": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "5": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "6": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "7": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "8": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "9": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "10": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "11": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        }
    },
    "167": {
        "0": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        }
    },
    "168": {
        "0": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        }
    },
    "169": {
        "0": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        }
    },
    "170": {
        "0": {
            "GXT": "CLO_SUM_G_1_0",
            "Localized": "Black Armored"
        },
        "1": {
            "GXT": "CLO_SUM_G_1_1",
            "Localized": "Gray Armored"
        },
        "2": {
            "GXT": "CLO_SUM_G_1_2",
            "Localized": "Ash Armored"
        },
        "3": {
            "GXT": "CLO_SUM_G_1_3",
            "Localized": "White Armored"
        },
        "4": {
            "GXT": "CLO_SUM_G_1_4",
            "Localized": "Red & Gray Armored"
        },
        "5": {
            "GXT": "CLO_SUM_G_1_5",
            "Localized": "Brown Armored"
        },
        "6": {
            "GXT": "CLO_SUM_G_1_6",
            "Localized": "Smoke Armored"
        },
        "7": {
            "GXT": "CLO_SUM_G_1_7",
            "Localized": "White & Green Armored"
        }
    },
    "171": {
        "0": {
            "GXT": "CLO_SUM_G_1_0",
            "Localized": "Black Armored"
        },
        "1": {
            "GXT": "CLO_SUM_G_1_1",
            "Localized": "Gray Armored"
        },
        "2": {
            "GXT": "CLO_SUM_G_1_2",
            "Localized": "Ash Armored"
        },
        "3": {
            "GXT": "CLO_SUM_G_1_3",
            "Localized": "White Armored"
        },
        "4": {
            "GXT": "CLO_SUM_G_1_4",
            "Localized": "Red & Gray Armored"
        },
        "5": {
            "GXT": "CLO_SUM_G_1_5",
            "Localized": "Brown Armored"
        },
        "6": {
            "GXT": "CLO_SUM_G_1_6",
            "Localized": "Smoke Armored"
        },
        "7": {
            "GXT": "CLO_SUM_G_1_7",
            "Localized": "White & Green Armored"
        }
    },
    "172": {
        "0": {
            "GXT": "CLO_SUM_G_1_0",
            "Localized": "Black Armored"
        },
        "1": {
            "GXT": "CLO_SUM_G_1_1",
            "Localized": "Gray Armored"
        },
        "2": {
            "GXT": "CLO_SUM_G_1_2",
            "Localized": "Ash Armored"
        },
        "3": {
            "GXT": "CLO_SUM_G_1_3",
            "Localized": "White Armored"
        },
        "4": {
            "GXT": "CLO_SUM_G_1_4",
            "Localized": "Red & Gray Armored"
        },
        "5": {
            "GXT": "CLO_SUM_G_1_5",
            "Localized": "Brown Armored"
        },
        "6": {
            "GXT": "CLO_SUM_G_1_6",
            "Localized": "Smoke Armored"
        },
        "7": {
            "GXT": "CLO_SUM_G_1_7",
            "Localized": "White & Green Armored"
        }
    },
    "173": {
        "0": {
            "GXT": "CLO_SUM_G_1_0",
            "Localized": "Black Armored"
        },
        "1": {
            "GXT": "CLO_SUM_G_1_1",
            "Localized": "Gray Armored"
        },
        "2": {
            "GXT": "CLO_SUM_G_1_2",
            "Localized": "Ash Armored"
        },
        "3": {
            "GXT": "CLO_SUM_G_1_3",
            "Localized": "White Armored"
        },
        "4": {
            "GXT": "CLO_SUM_G_1_4",
            "Localized": "Red & Gray Armored"
        },
        "5": {
            "GXT": "CLO_SUM_G_1_5",
            "Localized": "Brown Armored"
        },
        "6": {
            "GXT": "CLO_SUM_G_1_6",
            "Localized": "Smoke Armored"
        },
        "7": {
            "GXT": "CLO_SUM_G_1_7",
            "Localized": "White & Green Armored"
        }
    },
    "174": {
        "0": {
            "GXT": "CLO_SUM_G_1_0",
            "Localized": "Black Armored"
        },
        "1": {
            "GXT": "CLO_SUM_G_1_1",
            "Localized": "Gray Armored"
        },
        "2": {
            "GXT": "CLO_SUM_G_1_2",
            "Localized": "Ash Armored"
        },
        "3": {
            "GXT": "CLO_SUM_G_1_3",
            "Localized": "White Armored"
        },
        "4": {
            "GXT": "CLO_SUM_G_1_4",
            "Localized": "Red & Gray Armored"
        },
        "5": {
            "GXT": "CLO_SUM_G_1_5",
            "Localized": "Brown Armored"
        },
        "6": {
            "GXT": "CLO_SUM_G_1_6",
            "Localized": "Smoke Armored"
        },
        "7": {
            "GXT": "CLO_SUM_G_1_7",
            "Localized": "White & Green Armored"
        }
    },
    "175": {
        "0": {
            "GXT": "CLO_SUM_G_1_0",
            "Localized": "Black Armored"
        },
        "1": {
            "GXT": "CLO_SUM_G_1_1",
            "Localized": "Gray Armored"
        },
        "2": {
            "GXT": "CLO_SUM_G_1_2",
            "Localized": "Ash Armored"
        },
        "3": {
            "GXT": "CLO_SUM_G_1_3",
            "Localized": "White Armored"
        },
        "4": {
            "GXT": "CLO_SUM_G_1_4",
            "Localized": "Red & Gray Armored"
        },
        "5": {
            "GXT": "CLO_SUM_G_1_5",
            "Localized": "Brown Armored"
        },
        "6": {
            "GXT": "CLO_SUM_G_1_6",
            "Localized": "Smoke Armored"
        },
        "7": {
            "GXT": "CLO_SUM_G_1_7",
            "Localized": "White & Green Armored"
        }
    },
    "176": {
        "0": {
            "GXT": "CLO_SUM_G_1_0",
            "Localized": "Black Armored"
        },
        "1": {
            "GXT": "CLO_SUM_G_1_1",
            "Localized": "Gray Armored"
        },
        "2": {
            "GXT": "CLO_SUM_G_1_2",
            "Localized": "Ash Armored"
        },
        "3": {
            "GXT": "CLO_SUM_G_1_3",
            "Localized": "White Armored"
        },
        "4": {
            "GXT": "CLO_SUM_G_1_4",
            "Localized": "Red & Gray Armored"
        },
        "5": {
            "GXT": "CLO_SUM_G_1_5",
            "Localized": "Brown Armored"
        },
        "6": {
            "GXT": "CLO_SUM_G_1_6",
            "Localized": "Smoke Armored"
        },
        "7": {
            "GXT": "CLO_SUM_G_1_7",
            "Localized": "White & Green Armored"
        }
    },
    "177": {
        "0": {
            "GXT": "CLO_SUM_G_1_0",
            "Localized": "Black Armored"
        },
        "1": {
            "GXT": "CLO_SUM_G_1_1",
            "Localized": "Gray Armored"
        },
        "2": {
            "GXT": "CLO_SUM_G_1_2",
            "Localized": "Ash Armored"
        },
        "3": {
            "GXT": "CLO_SUM_G_1_3",
            "Localized": "White Armored"
        },
        "4": {
            "GXT": "CLO_SUM_G_1_4",
            "Localized": "Red & Gray Armored"
        },
        "5": {
            "GXT": "CLO_SUM_G_1_5",
            "Localized": "Brown Armored"
        },
        "6": {
            "GXT": "CLO_SUM_G_1_6",
            "Localized": "Smoke Armored"
        },
        "7": {
            "GXT": "CLO_SUM_G_1_7",
            "Localized": "White & Green Armored"
        }
    },
    "178": {
        "0": {
            "GXT": "CLO_SUM_G_1_0",
            "Localized": "Black Armored"
        },
        "1": {
            "GXT": "CLO_SUM_G_1_1",
            "Localized": "Gray Armored"
        },
        "2": {
            "GXT": "CLO_SUM_G_1_2",
            "Localized": "Ash Armored"
        },
        "3": {
            "GXT": "CLO_SUM_G_1_3",
            "Localized": "White Armored"
        },
        "4": {
            "GXT": "CLO_SUM_G_1_4",
            "Localized": "Red & Gray Armored"
        },
        "5": {
            "GXT": "CLO_SUM_G_1_5",
            "Localized": "Brown Armored"
        },
        "6": {
            "GXT": "CLO_SUM_G_1_6",
            "Localized": "Smoke Armored"
        },
        "7": {
            "GXT": "CLO_SUM_G_1_7",
            "Localized": "White & Green Armored"
        }
    },
    "179": {
        "0": {
            "GXT": "CLO_SUM_G_1_0",
            "Localized": "Black Armored"
        },
        "1": {
            "GXT": "CLO_SUM_G_1_1",
            "Localized": "Gray Armored"
        },
        "2": {
            "GXT": "CLO_SUM_G_1_2",
            "Localized": "Ash Armored"
        },
        "3": {
            "GXT": "CLO_SUM_G_1_3",
            "Localized": "White Armored"
        },
        "4": {
            "GXT": "CLO_SUM_G_1_4",
            "Localized": "Red & Gray Armored"
        },
        "5": {
            "GXT": "CLO_SUM_G_1_5",
            "Localized": "Brown Armored"
        },
        "6": {
            "GXT": "CLO_SUM_G_1_6",
            "Localized": "Smoke Armored"
        },
        "7": {
            "GXT": "CLO_SUM_G_1_7",
            "Localized": "White & Green Armored"
        }
    },
    "180": {
        "0": {
            "GXT": "CLO_SUM_G_1_0",
            "Localized": "Black Armored"
        },
        "1": {
            "GXT": "CLO_SUM_G_1_1",
            "Localized": "Gray Armored"
        },
        "2": {
            "GXT": "CLO_SUM_G_1_2",
            "Localized": "Ash Armored"
        },
        "3": {
            "GXT": "CLO_SUM_G_1_3",
            "Localized": "White Armored"
        },
        "4": {
            "GXT": "CLO_SUM_G_1_4",
            "Localized": "Red & Gray Armored"
        },
        "5": {
            "GXT": "CLO_SUM_G_1_5",
            "Localized": "Brown Armored"
        },
        "6": {
            "GXT": "CLO_SUM_G_1_6",
            "Localized": "Smoke Armored"
        },
        "7": {
            "GXT": "CLO_SUM_G_1_7",
            "Localized": "White & Green Armored"
        }
    },
    "181": {
        "0": {
            "GXT": "CLO_SUM_G_1_0",
            "Localized": "Black Armored"
        },
        "1": {
            "GXT": "CLO_SUM_G_1_1",
            "Localized": "Gray Armored"
        },
        "2": {
            "GXT": "CLO_SUM_G_1_2",
            "Localized": "Ash Armored"
        },
        "3": {
            "GXT": "CLO_SUM_G_1_3",
            "Localized": "White Armored"
        },
        "4": {
            "GXT": "CLO_SUM_G_1_4",
            "Localized": "Red & Gray Armored"
        },
        "5": {
            "GXT": "CLO_SUM_G_1_5",
            "Localized": "Brown Armored"
        },
        "6": {
            "GXT": "CLO_SUM_G_1_6",
            "Localized": "Smoke Armored"
        },
        "7": {
            "GXT": "CLO_SUM_G_1_7",
            "Localized": "White & Green Armored"
        }
    },
    "182": {
        "0": {
            "GXT": "CLO_SUM_G_1_0",
            "Localized": "Black Armored"
        },
        "1": {
            "GXT": "CLO_SUM_G_1_1",
            "Localized": "Gray Armored"
        },
        "2": {
            "GXT": "CLO_SUM_G_1_2",
            "Localized": "Ash Armored"
        },
        "3": {
            "GXT": "CLO_SUM_G_1_3",
            "Localized": "White Armored"
        },
        "4": {
            "GXT": "CLO_SUM_G_1_4",
            "Localized": "Red & Gray Armored"
        },
        "5": {
            "GXT": "CLO_SUM_G_1_5",
            "Localized": "Brown Armored"
        },
        "6": {
            "GXT": "CLO_SUM_G_1_6",
            "Localized": "Smoke Armored"
        },
        "7": {
            "GXT": "CLO_SUM_G_1_7",
            "Localized": "White & Green Armored"
        }
    },
    "183": {
        "0": {
            "GXT": "CLO_SUM_G_1_0",
            "Localized": "Black Armored"
        },
        "1": {
            "GXT": "CLO_SUM_G_1_1",
            "Localized": "Gray Armored"
        },
        "2": {
            "GXT": "CLO_SUM_G_1_2",
            "Localized": "Ash Armored"
        },
        "3": {
            "GXT": "CLO_SUM_G_1_3",
            "Localized": "White Armored"
        },
        "4": {
            "GXT": "CLO_SUM_G_1_4",
            "Localized": "Red & Gray Armored"
        },
        "5": {
            "GXT": "CLO_SUM_G_1_5",
            "Localized": "Brown Armored"
        },
        "6": {
            "GXT": "CLO_SUM_G_1_6",
            "Localized": "Smoke Armored"
        },
        "7": {
            "GXT": "CLO_SUM_G_1_7",
            "Localized": "White & Green Armored"
        }
    },
    "184": {
        "0": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        }
    },
    "185": {
        "0": {
            "GXT": "CLO_HSTM_G_0_0",
            "Localized": "Black Driving Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_0_1",
            "Localized": "Brown Driving Gloves"
        }
    },
    "186": {
        "0": {
            "GXT": "CLO_HSTM_G_1_0",
            "Localized": "Black Leather Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_1_1",
            "Localized": "Brown Leather Gloves"
        }
    },
    "187": {
        "0": {
            "GXT": "CLO_HSTM_G_2_0",
            "Localized": "Black Woolen Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_2_1",
            "Localized": "Gray Woolen Gloves"
        }
    },
    "188": {
        "0": {
            "GXT": "CLO_HSTM_G_3_0",
            "Localized": "Black Fingerless Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_3_1",
            "Localized": "Gray Fingerless Gloves"
        }
    },
    "189": {
        "0": {
            "GXT": "CLO_HSTM_G_6_0",
            "Localized": "Refuse Collector Gloves"
        }
    },
    "190": {
        "0": {
            "GXT": "CLO_HSTM_G_4_0",
            "Localized": "White Cotton Gloves"
        }
    },
    "191": {
        "0": {
            "GXT": "CLO_HSTM_G_5_0",
            "Localized": "Blue Surgical Gloves"
        },
        "1": {
            "GXT": "CLO_HSTM_G_5_1",
            "Localized": "White Surgical Gloves"
        }
    },
    "192": {
        "0": {
            "GXT": "CLO_GRM_G_0_0",
            "Localized": "Blue Digital Armored"
        },
        "1": {
            "GXT": "CLO_GRM_G_0_1",
            "Localized": "Brown Digital Armored"
        },
        "2": {
            "GXT": "CLO_GRM_G_0_2",
            "Localized": "Green Digital Armored"
        },
        "3": {
            "GXT": "CLO_GRM_G_0_3",
            "Localized": "Gray Digital Armored"
        },
        "4": {
            "GXT": "CLO_GRM_G_0_4",
            "Localized": "Peach Digital Armored"
        },
        "5": {
            "GXT": "CLO_GRM_G_0_5",
            "Localized": "Fall Armored"
        },
        "6": {
            "GXT": "CLO_GRM_G_0_6",
            "Localized": "Dark Woodland Armored"
        },
        "7": {
            "GXT": "CLO_GRM_G_0_7",
            "Localized": "Crosshatch Armored"
        },
        "8": {
            "GXT": "CLO_GRM_G_0_8",
            "Localized": "Moss Digital Armored"
        },
        "9": {
            "GXT": "CLO_GRM_G_0_9",
            "Localized": "Gray Woodland Armored"
        },
        "10": {
            "GXT": "CLO_GRM_G_0_10",
            "Localized": "Aqua Camo Armored"
        },
        "11": {
            "GXT": "CLO_GRM_G_0_11",
            "Localized": "Splinter Armored"
        },
        "12": {
            "GXT": "CLO_GRM_G_0_12",
            "Localized": "Contrast Camo Armored"
        },
        "13": {
            "GXT": "CLO_GRM_G_0_13",
            "Localized": "Cobble Armored"
        },
        "14": {
            "GXT": "CLO_GRM_G_0_14",
            "Localized": "Peach Camo Armored"
        },
        "15": {
            "GXT": "CLO_GRM_G_0_15",
            "Localized": "Brushstroke Armored"
        },
        "16": {
            "GXT": "CLO_GRM_G_0_16",
            "Localized": "Flecktarn Armored"
        },
        "17": {
            "GXT": "CLO_GRM_G_0_17",
            "Localized": "Light Woodland Armored"
        },
        "18": {
            "GXT": "CLO_GRM_G_0_18",
            "Localized": "Moss Armored"
        },
        "19": {
            "GXT": "CLO_GRM_G_0_19",
            "Localized": "Sand Armored"
        }
    },
    "193": {
        "0": {
            "GXT": "CLO_GRM_G_1_0",
            "Localized": "Blue Digital Tactical"
        },
        "1": {
            "GXT": "CLO_GRM_G_1_1",
            "Localized": "Brown Digital Tactical"
        },
        "2": {
            "GXT": "CLO_GRM_G_1_2",
            "Localized": "Green Digital Tactical"
        },
        "3": {
            "GXT": "CLO_GRM_G_1_3",
            "Localized": "Gray Digital Tactical"
        },
        "4": {
            "GXT": "CLO_GRM_G_1_4",
            "Localized": "Peach Digital Tactical"
        },
        "5": {
            "GXT": "CLO_GRM_G_1_5",
            "Localized": "Fall Tactical"
        },
        "6": {
            "GXT": "CLO_GRM_G_1_6",
            "Localized": "Dark Woodland Tactical"
        },
        "7": {
            "GXT": "CLO_GRM_G_1_7",
            "Localized": "Crosshatch Tactical"
        },
        "8": {
            "GXT": "CLO_GRM_G_1_8",
            "Localized": "Moss Digital Tactical"
        },
        "9": {
            "GXT": "CLO_GRM_G_1_9",
            "Localized": "Gray Woodland Tactical"
        },
        "10": {
            "GXT": "CLO_GRM_G_1_10",
            "Localized": "Aqua Camo Tactical"
        },
        "11": {
            "GXT": "CLO_GRM_G_1_11",
            "Localized": "Splinter Tactical"
        },
        "12": {
            "GXT": "CLO_GRM_G_1_12",
            "Localized": "Contrast Camo Tactical"
        },
        "13": {
            "GXT": "CLO_GRM_G_1_13",
            "Localized": "Cobble Tactical"
        },
        "14": {
            "GXT": "CLO_GRM_G_1_14",
            "Localized": "Peach Camo Tactical"
        },
        "15": {
            "GXT": "CLO_GRM_G_1_15",
            "Localized": "Brushstroke Tactical"
        },
        "16": {
            "GXT": "CLO_GRM_G_1_16",
            "Localized": "Flecktarn Tactical"
        },
        "17": {
            "GXT": "CLO_GRM_G_1_17",
            "Localized": "Light Woodland Tactical"
        },
        "18": {
            "GXT": "CLO_GRM_G_1_18",
            "Localized": "Moss Tactical"
        },
        "19": {
            "GXT": "CLO_GRM_G_1_19",
            "Localized": "Sand Tactical"
        }
    },
    "194": {
        "0": {
            "GXT": "CLO_SUM_G_1_0",
            "Localized": "Black Armored"
        },
        "1": {
            "GXT": "CLO_SUM_G_1_1",
            "Localized": "Gray Armored"
        },
        "2": {
            "GXT": "CLO_SUM_G_1_2",
            "Localized": "Ash Armored"
        },
        "3": {
            "GXT": "CLO_SUM_G_1_3",
            "Localized": "White Armored"
        },
        "4": {
            "GXT": "CLO_SUM_G_1_4",
            "Localized": "Red & Gray Armored"
        },
        "5": {
            "GXT": "CLO_SUM_G_1_5",
            "Localized": "Brown Armored"
        },
        "6": {
            "GXT": "CLO_SUM_G_1_6",
            "Localized": "Smoke Armored"
        },
        "7": {
            "GXT": "CLO_SUM_G_1_7",
            "Localized": "White & Green Armored"
        }
    }
}
`