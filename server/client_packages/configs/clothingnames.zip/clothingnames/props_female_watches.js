exports = `{
    "0": {
        "0": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "1": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "2": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "3": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "4": {
            "GXT": "W_FMF_0_4",
            "Localized": "Pewter Watch"
        }
    },
    "1": {
        "0": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "1": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "2": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "3": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        },
        "4": {
            "GXT": "NO_LABEL",
            "Localized": "NULL"
        }
    },
    "2": {
        "0": {
            "GXT": "CLO_BUSF_W0_0",
            "Localized": "Gold Fashion"
        },
        "1": {
            "GXT": "CLO_BUSF_W0_1",
            "Localized": "Silver Fashion"
        },
        "2": {
            "GXT": "CLO_BUSF_W0_2",
            "Localized": "Copper Fashion"
        },
        "3": {
            "GXT": "CLO_BUSF_W0_3",
            "Localized": "Black Fashion"
        }
    },
    "3": {
        "0": {
            "GXT": "CLO_LXF_LW_0_0",
            "Localized": "Gold CaCa Di Lusso"
        },
        "1": {
            "GXT": "CLO_LXF_LW_0_1",
            "Localized": "Silver CaCa Di Lusso"
        },
        "2": {
            "GXT": "CLO_LXF_LW_0_2",
            "Localized": "Pink Gold CaCa Di Lusso"
        }
    },
    "4": {
        "0": {
            "GXT": "CLO_LXF_LW_1_0",
            "Localized": "Silver Didier Sachs Mignon"
        },
        "1": {
            "GXT": "CLO_LXF_LW_1_1",
            "Localized": "Pink Gold Didier Sachs Mignon"
        },
        "2": {
            "GXT": "CLO_LXF_LW_1_2",
            "Localized": "Gold Didier Sachs Mignon"
        }
    },
    "5": {
        "0": {
            "GXT": "CLO_LXF_LW_5_0",
            "Localized": "Gold iFruit Link"
        },
        "1": {
            "GXT": "CLO_LXF_LW_5_1",
            "Localized": "Silver iFruit Link"
        },
        "2": {
            "GXT": "CLO_LXF_LW_5_2",
            "Localized": "Pink Gold iFruit Link"
        }
    },
    "6": {
        "0": {
            "GXT": "CLO_LXF_LW_6_0",
            "Localized": "White iFruit Tech"
        },
        "1": {
            "GXT": "CLO_LXF_LW_6_1",
            "Localized": "Pink iFruit Tech"
        },
        "2": {
            "GXT": "CLO_LXF_LW_6_2",
            "Localized": "PRB iFruit Tech"
        }
    },
    "7": {
        "0": {
            "GXT": "CLO_L2F_LW_2_0",
            "Localized": "Gold Le Chien Marquise"
        },
        "1": {
            "GXT": "CLO_L2F_LW_2_1",
            "Localized": "Silver Le Chien Marquise"
        },
        "2": {
            "GXT": "CLO_L2F_LW_2_2",
            "Localized": "Pink Gold Le Chien Marquise"
        }
    },
    "8": {
        "0": {
            "GXT": "CLO_L2F_LW_3_0",
            "Localized": "Gray Fufu Jeunesse"
        },
        "1": {
            "GXT": "CLO_L2F_LW_3_1",
            "Localized": "Black Fufu Jeunesse"
        },
        "2": {
            "GXT": "CLO_L2F_LW_3_2",
            "Localized": "Blue Fufu Jeunesse"
        }
    },
    "9": {
        "0": {
            "GXT": "CLO_L2F_LW_4_0",
            "Localized": "Silver Anna Rex Prestige"
        },
        "1": {
            "GXT": "CLO_L2F_LW_4_1",
            "Localized": "Gold Anna Rex Prestige"
        },
        "2": {
            "GXT": "CLO_L2F_LW_4_2",
            "Localized": "Carbon Anna Rex Prestige"
        }
    },
    "10": {
        "0": {
            "GXT": "CLO_L2F_LW_7_0",
            "Localized": "Lime iFruit Snap"
        },
        "1": {
            "GXT": "CLO_L2F_LW_7_1",
            "Localized": "White iFruit Snap"
        },
        "2": {
            "GXT": "CLO_L2F_LW_7_2",
            "Localized": "Neon iFruit Snap"
        }
    },
    "11": {
        "0": {
            "GXT": "CLO_BIF_PW_0_0",
            "Localized": "Light Wrist Chain (L)"
        }
    },
    "12": {
        "0": {
            "GXT": "CLO_BIF_PW_1_0",
            "Localized": "Chunky Wrist Chain (L)"
        }
    },
    "13": {
        "0": {
            "GXT": "CLO_BIF_PW_2_0",
            "Localized": "Square Wrist Chain (L)"
        }
    },
    "14": {
        "0": {
            "GXT": "CLO_BIF_PW_3_0",
            "Localized": "Skull Wrist Chain (L)"
        }
    },
    "15": {
        "0": {
            "GXT": "CLO_BIF_PW_4_0",
            "Localized": "Tread Wrist Chain (L)"
        }
    },
    "16": {
        "0": {
            "GXT": "CLO_BIF_PW_5_0",
            "Localized": "Gear Wrist Chains (L)"
        }
    },
    "17": {
        "0": {
            "GXT": "CLO_BIF_PW_6_0",
            "Localized": "Spiked Gauntlet (L)"
        }
    },
    "18": {
        "0": {
            "GXT": "CLO_BIF_PW_7_0",
            "Localized": "Black Gauntlet (L)"
        },
        "1": {
            "GXT": "CLO_BIF_PW_7_1",
            "Localized": "Chocolate Gauntlet (L)"
        },
        "2": {
            "GXT": "CLO_BIF_PW_7_2",
            "Localized": "Tan Gauntlet (L)"
        },
        "3": {
            "GXT": "CLO_BIF_PW_7_3",
            "Localized": "Ox Blood Gauntlet (L)"
        }
    },
    "19": {
        "0": {
            "GXT": "CLO_VWF_PW_0_0",
            "Localized": "Gold Enduring Watch"
        },
        "1": {
            "GXT": "CLO_VWF_PW_0_1",
            "Localized": "Silver Enduring Watch"
        },
        "2": {
            "GXT": "CLO_VWF_PW_0_2",
            "Localized": "Black Enduring Watch"
        },
        "3": {
            "GXT": "CLO_VWF_PW_0_3",
            "Localized": "Deck Enduring Watch"
        },
        "4": {
            "GXT": "CLO_VWF_PW_0_4",
            "Localized": "Royal Enduring Watch"
        },
        "5": {
            "GXT": "CLO_VWF_PW_0_5",
            "Localized": "Roulette Enduring Watch"
        }
    },
    "20": {
        "0": {
            "GXT": "CLO_VWF_PW_1_0",
            "Localized": "Gold Kronos Tempo"
        },
        "1": {
            "GXT": "CLO_VWF_PW_1_1",
            "Localized": "Silver Kronos Tempo"
        },
        "2": {
            "GXT": "CLO_VWF_PW_1_2",
            "Localized": "Black Kronos Tempo"
        },
        "3": {
            "GXT": "CLO_VWF_PW_1_3",
            "Localized": "Gold Fifty Kronos Tempo"
        },
        "4": {
            "GXT": "CLO_VWF_PW_1_4",
            "Localized": "Gold Roulette Kronos Tempo"
        },
        "5": {
            "GXT": "CLO_VWF_PW_1_5",
            "Localized": "Baroque Kronos Tempo"
        }
    },
    "21": {
        "0": {
            "GXT": "CLO_VWF_PW_2_0",
            "Localized": "Gold Kronos Pulse"
        },
        "1": {
            "GXT": "CLO_VWF_PW_2_1",
            "Localized": "Silver Kronos Pulse"
        },
        "2": {
            "GXT": "CLO_VWF_PW_2_2",
            "Localized": "Black Kronos Pulse"
        },
        "3": {
            "GXT": "CLO_VWF_PW_2_3",
            "Localized": "Silver Fifty Kronos Pulse"
        },
        "4": {
            "GXT": "CLO_VWF_PW_2_4",
            "Localized": "Silver Roulette Kronos Pulse"
        },
        "5": {
            "GXT": "CLO_VWF_PW_2_5",
            "Localized": "Spade Kronos Pulse"
        },
        "6": {
            "GXT": "CLO_VWF_PW_2_6",
            "Localized": "Red Fame or Shame Kronos"
        },
        "7": {
            "GXT": "CLO_VWF_PW_2_7",
            "Localized": "Green Fame or Shame Kronos"
        },
        "8": {
            "GXT": "CLO_VWF_PW_2_8",
            "Localized": "Blue Fame or Shame Kronos"
        },
        "9": {
            "GXT": "CLO_VWF_PW_2_9",
            "Localized": "Black Fame or Shame Kronos"
        }
    },
    "22": {
        "0": {
            "GXT": "CLO_VWF_PW_3_0",
            "Localized": "Gold Kronos Ära"
        },
        "1": {
            "GXT": "CLO_VWF_PW_3_1",
            "Localized": "Silver Kronos Ära"
        },
        "2": {
            "GXT": "CLO_VWF_PW_3_2",
            "Localized": "Black Kronos Ära"
        },
        "3": {
            "GXT": "CLO_VWF_PW_3_3",
            "Localized": "Gold Fifty Kronos Ära"
        },
        "4": {
            "GXT": "CLO_VWF_PW_3_4",
            "Localized": "Tan Spade Kronos Ära"
        },
        "5": {
            "GXT": "CLO_VWF_PW_3_5",
            "Localized": "Brown Spade Kronos Ära"
        }
    },
    "23": {
        "0": {
            "GXT": "CLO_VWF_PW_4_0",
            "Localized": "Gold Ceaseless"
        },
        "1": {
            "GXT": "CLO_VWF_PW_4_1",
            "Localized": "Silver Ceaseless"
        },
        "2": {
            "GXT": "CLO_VWF_PW_4_2",
            "Localized": "Black Ceaseless"
        },
        "3": {
            "GXT": "CLO_VWF_PW_4_3",
            "Localized": "Spade Ceaseless"
        },
        "4": {
            "GXT": "CLO_VWF_PW_4_4",
            "Localized": "Mixed Metals Ceaseless"
        },
        "5": {
            "GXT": "CLO_VWF_PW_4_5",
            "Localized": "Roulette Ceaseless"
        }
    },
    "24": {
        "0": {
            "GXT": "CLO_VWF_PW_5_0",
            "Localized": "Silver Crowex Époque"
        },
        "1": {
            "GXT": "CLO_VWF_PW_5_1",
            "Localized": "Gold Crowex Époque"
        },
        "2": {
            "GXT": "CLO_VWF_PW_5_2",
            "Localized": "Black Crowex Époque"
        },
        "3": {
            "GXT": "CLO_VWF_PW_5_3",
            "Localized": "Wheel Crowex Époque"
        },
        "4": {
            "GXT": "CLO_VWF_PW_5_4",
            "Localized": "Suits Crowex Époque"
        },
        "5": {
            "GXT": "CLO_VWF_PW_5_5",
            "Localized": "Roulette Crowex Époque"
        }
    },
    "25": {
        "0": {
            "GXT": "CLO_VWF_PW_6_0",
            "Localized": "Gold Kronos Quad"
        },
        "1": {
            "GXT": "CLO_VWF_PW_6_1",
            "Localized": "Silver Kronos Quad"
        },
        "2": {
            "GXT": "CLO_VWF_PW_6_2",
            "Localized": "Black Kronos Quad"
        },
        "3": {
            "GXT": "CLO_VWF_PW_6_3",
            "Localized": "Roulette Kronos Quad"
        },
        "4": {
            "GXT": "CLO_VWF_PW_6_4",
            "Localized": "Fifty Kronos Quad"
        },
        "5": {
            "GXT": "CLO_VWF_PW_6_5",
            "Localized": "Suits Kronos Quad"
        }
    },
    "26": {
        "0": {
            "GXT": "CLO_VWF_PW_7_0",
            "Localized": "Silver Crowex Rond"
        },
        "1": {
            "GXT": "CLO_VWF_PW_7_1",
            "Localized": "Gold Crowex Rond"
        },
        "2": {
            "GXT": "CLO_VWF_PW_7_2",
            "Localized": "Black Crowex Rond"
        },
        "3": {
            "GXT": "CLO_VWF_PW_7_3",
            "Localized": "Spade Crowex Rond"
        },
        "4": {
            "GXT": "CLO_VWF_PW_7_4",
            "Localized": "Royalty Crowex Rond"
        },
        "5": {
            "GXT": "CLO_VWF_PW_7_5",
            "Localized": "Dice Crowex Rond"
        }
    },
    "27": {
        "0": {
            "GXT": "CLO_VWF_PW_8_0",
            "Localized": "Silver SASS Wrist Piece"
        },
        "1": {
            "GXT": "CLO_VWF_PW_8_1",
            "Localized": "Gold SASS Wrist Piece"
        },
        "2": {
            "GXT": "CLO_VWF_PW_8_2",
            "Localized": "Black SASS Wrist Piece"
        }
    },
    "28": {
        "0": {
            "GXT": "CLO_VWF_PW_9_0",
            "Localized": "Silver SASS Bracelet"
        },
        "1": {
            "GXT": "CLO_VWF_PW_9_1",
            "Localized": "Gold SASS Bracelet"
        },
        "2": {
            "GXT": "CLO_VWF_PW_9_2",
            "Localized": "Black SASS Bracelet"
        }
    },
    "29": {
        "0": {
            "GXT": "CLO_H4F_PLW_0_0",
            "Localized": "Blue Bangles (L)"
        },
        "1": {
            "GXT": "CLO_H4F_PLW_0_1",
            "Localized": "Red Bangles (L)"
        },
        "2": {
            "GXT": "CLO_H4F_PLW_0_2",
            "Localized": "Pink Bangles (L)"
        },
        "3": {
            "GXT": "CLO_H4F_PLW_0_3",
            "Localized": "Yellow Bangles (L)"
        },
        "4": {
            "GXT": "CLO_H4F_PLW_0_4",
            "Localized": "Orange Bangles (L)"
        },
        "5": {
            "GXT": "CLO_H4F_PLW_0_5",
            "Localized": "Green Bangles (L)"
        },
        "6": {
            "GXT": "CLO_H4F_PLW_0_6",
            "Localized": "Red & Blue Bangles (L)"
        },
        "7": {
            "GXT": "CLO_H4F_PLW_0_7",
            "Localized": "Yellow & Orange Bangles (L)"
        },
        "8": {
            "GXT": "CLO_H4F_PLW_0_8",
            "Localized": "Green & Pink Bangles (L)"
        },
        "9": {
            "GXT": "CLO_H4F_PLW_0_9",
            "Localized": "Rainbow Bangles (L)"
        },
        "10": {
            "GXT": "CLO_H4F_PLW_010",
            "Localized": "Sunset Bangles (L)"
        },
        "11": {
            "GXT": "CLO_H4F_PLW_011",
            "Localized": "Tropical Bangles (L)"
        }
    }
}
`