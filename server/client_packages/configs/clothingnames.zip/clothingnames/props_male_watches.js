exports = `{
    "0": {
        "0": {
            "GXT": "W_FMM_0_0",
            "Localized": "Deep Sea Watch"
        },
        "1": {
            "GXT": "W_FMM_0_1",
            "Localized": "Gold Watch"
        },
        "2": {
            "GXT": "W_FMM_0_2",
            "Localized": "Silver Watch"
        },
        "3": {
            "GXT": "W_FMM_0_3",
            "Localized": "Black Watch"
        },
        "4": {
            "GXT": "W_FMM_0_4",
            "Localized": "Gold Faced Silver Watch"
        }
    },
    "1": {
        "0": {
            "GXT": "W_FMM_1_0",
            "Localized": "White LED, Black Strap"
        },
        "1": {
            "GXT": "W_FMM_1_1",
            "Localized": "Red LED, White Strap"
        },
        "2": {
            "GXT": "W_FMM_1_2",
            "Localized": "Red LED, Brown Strap"
        },
        "3": {
            "GXT": "W_FMM_1_3",
            "Localized": "White LED, Tan Strap"
        },
        "4": {
            "GXT": "W_FMM_1_4",
            "Localized": "Yellow LED"
        }
    },
    "2": {
        "0": {
            "GXT": "W_FMM_2_0",
            "Localized": "Black Sports"
        },
        "1": {
            "GXT": "W_FMM_2_1",
            "Localized": "Red Sports"
        },
        "2": {
            "GXT": "W_FMM_2_2",
            "Localized": "White Sports"
        },
        "3": {
            "GXT": "W_FMM_2_3",
            "Localized": "Yellow Sports"
        },
        "4": {
            "GXT": "W_FMM_2_4",
            "Localized": "Blue Sports"
        }
    },
    "3": {
        "0": {
            "GXT": "CLO_BBM_W_1_0",
            "Localized": "Pendulus Sport Black Sports"
        },
        "1": {
            "GXT": "CLO_BBM_W_1_1",
            "Localized": "Pfister Design Red Sports"
        },
        "2": {
            "GXT": "CLO_BBM_W_1_2",
            "Localized": "White Sports"
        },
        "3": {
            "GXT": "CLO_BBM_W_1_3",
            "Localized": "Yellow Sports"
        },
        "4": {
            "GXT": "CLO_BBM_W_1_4",
            "Localized": "Blue Sports"
        }
    },
    "4": {
        "0": {
            "GXT": "CLO_BUSM_W0_0",
            "Localized": "Gold Watch"
        },
        "1": {
            "GXT": "CLO_BUSM_W0_1",
            "Localized": "Silver Watch"
        },
        "2": {
            "GXT": "CLO_BUSM_W0_2",
            "Localized": "Black Watch"
        },
        "3": {
            "GXT": "CLO_BUSM_W0_3",
            "Localized": "White Gold Watch"
        }
    },
    "5": {
        "0": {
            "GXT": "CLO_HP_W_0_0",
            "Localized": "Red LED, White Strap"
        },
        "1": {
            "GXT": "CLO_HP_W_0_1",
            "Localized": "Red LED, Brown Strap"
        },
        "2": {
            "GXT": "CLO_HP_W_0_2",
            "Localized": "White LED, Gold Strap"
        },
        "3": {
            "GXT": "CLO_HP_W_0_3",
            "Localized": "Yellow LED, Yellow Strap"
        }
    },
    "6": {
        "0": {
            "GXT": "CLO_LXM_W_0_0",
            "Localized": "Pink Gold Kronos Quantum"
        },
        "1": {
            "GXT": "CLO_LXM_W_0_1",
            "Localized": "Silver Kronos Quantum"
        },
        "2": {
            "GXT": "CLO_LXM_W_0_2",
            "Localized": "Carbon Kronos Quantum"
        }
    },
    "7": {
        "0": {
            "GXT": "CLO_LXM_W_1_0",
            "Localized": "Platinum Gaulle Retro Hex"
        },
        "1": {
            "GXT": "CLO_LXM_W_1_1",
            "Localized": "Carbon Gaulle Retro Hex"
        },
        "2": {
            "GXT": "CLO_LXM_W_1_2",
            "Localized": "Gold Gaulle Retro Hex"
        }
    },
    "8": {
        "0": {
            "GXT": "CLO_LXM_W_2_0",
            "Localized": "Gold Covgari Supernova"
        },
        "1": {
            "GXT": "CLO_LXM_W_2_1",
            "Localized": "Carbon Covgari Supernova"
        },
        "2": {
            "GXT": "CLO_LXM_W_2_2",
            "Localized": "Pink Gold Covgari Supernova"
        }
    },
    "9": {
        "0": {
            "GXT": "CLO_LXM_W_3_0",
            "Localized": "Platinum Pendulus Galaxis"
        },
        "1": {
            "GXT": "CLO_LXM_W_3_1",
            "Localized": "Carbon Pendulus Galaxis"
        },
        "2": {
            "GXT": "CLO_LXM_W_3_2",
            "Localized": "Gold Pendulus Galaxis"
        }
    },
    "10": {
        "0": {
            "GXT": "CLO_LXM_W_4_0",
            "Localized": "Silver Crowex Chromosphere"
        },
        "1": {
            "GXT": "CLO_LXM_W_4_1",
            "Localized": "Gold Crowex Chromosphere"
        },
        "2": {
            "GXT": "CLO_LXM_W_4_2",
            "Localized": "Carbon Crowex Chromosphere"
        }
    },
    "11": {
        "0": {
            "GXT": "CLO_LXM_W_5_0",
            "Localized": "Pink Gold Vangelico Geomeister"
        },
        "1": {
            "GXT": "CLO_LXM_W_5_1",
            "Localized": "Silver Vangelico Geomeister"
        },
        "2": {
            "GXT": "CLO_LXM_W_5_2",
            "Localized": "Gold Vangelico Geomeister"
        }
    },
    "12": {
        "0": {
            "GXT": "CLO_LXM_W_13_0",
            "Localized": "Gold iFruit Link"
        },
        "1": {
            "GXT": "CLO_LXM_W_13_1",
            "Localized": "Silver iFruit Link"
        },
        "2": {
            "GXT": "CLO_LXM_W_13_2",
            "Localized": "Pink Gold iFruit Link"
        }
    },
    "13": {
        "0": {
            "GXT": "CLO_LXM_W_14_0",
            "Localized": "Carbon iFruit Tech"
        },
        "1": {
            "GXT": "CLO_LXM_W_14_1",
            "Localized": "Lime iFruit Tech"
        },
        "2": {
            "GXT": "CLO_LXM_W_14_2",
            "Localized": "PRB iFruit Tech"
        }
    },
    "14": {
        "0": {
            "GXT": "CLO_L2M_W_6_0",
            "Localized": "Silver Covgari Explorer"
        },
        "1": {
            "GXT": "CLO_L2M_W_6_1",
            "Localized": "Pink Gold Covgari Explorer"
        },
        "2": {
            "GXT": "CLO_L2M_W_6_2",
            "Localized": "Gold Covgari Explorer"
        }
    },
    "15": {
        "0": {
            "GXT": "CLO_L2M_W_7_0",
            "Localized": "Silver Pendulus Gravity"
        },
        "1": {
            "GXT": "CLO_L2M_W_7_1",
            "Localized": "Gold Pendulus Gravity"
        },
        "2": {
            "GXT": "CLO_L2M_W_7_2",
            "Localized": "Platinum Pendulus Gravity"
        }
    },
    "16": {
        "0": {
            "GXT": "CLO_L2M_W_8_0",
            "Localized": "Gold Covgari Universe"
        },
        "1": {
            "GXT": "CLO_L2M_W_8_1",
            "Localized": "Silver Covgari Universe"
        },
        "2": {
            "GXT": "CLO_L2M_W_8_2",
            "Localized": "Steel Covgari Universe"
        }
    },
    "17": {
        "0": {
            "GXT": "CLO_L2M_W_9_0",
            "Localized": "Copper Gaulle Destiny"
        },
        "1": {
            "GXT": "CLO_L2M_W_9_1",
            "Localized": "Vintage Gaulle Destiny"
        },
        "2": {
            "GXT": "CLO_L2M_W_9_2",
            "Localized": "Silver Gaulle Destiny"
        }
    },
    "18": {
        "0": {
            "GXT": "CLO_L2M_W_10_0",
            "Localized": "Carbon Medici Radial"
        },
        "1": {
            "GXT": "CLO_L2M_W_10_1",
            "Localized": "Silver Medici Radial"
        },
        "2": {
            "GXT": "CLO_L2M_W_10_2",
            "Localized": "Steel Medici Radial"
        }
    },
    "19": {
        "0": {
            "GXT": "CLO_L2M_W_11_0",
            "Localized": "Silver Pendulus Timestar"
        },
        "1": {
            "GXT": "CLO_L2M_W_11_1",
            "Localized": "Gold Pendulus Timestar"
        },
        "2": {
            "GXT": "CLO_L2M_W_11_2",
            "Localized": "Carbon Pendulus Timestar"
        }
    },
    "20": {
        "0": {
            "GXT": "CLO_L2M_W_12_0",
            "Localized": "Carbon Kronos Submariner"
        },
        "1": {
            "GXT": "CLO_L2M_W_12_1",
            "Localized": "Red Kronos Submariner"
        },
        "2": {
            "GXT": "CLO_L2M_W_12_2",
            "Localized": "Yellow Kronos Submariner"
        }
    },
    "21": {
        "0": {
            "GXT": "CLO_L2M_W_15_0",
            "Localized": "Red iFruit Snap"
        },
        "1": {
            "GXT": "CLO_L2M_W_15_1",
            "Localized": "Blue iFruit Snap"
        },
        "2": {
            "GXT": "CLO_L2M_W_15_2",
            "Localized": "Mint iFruit Snap"
        }
    },
    "22": {
        "0": {
            "GXT": "CLO_BIM_PW_0_0",
            "Localized": "Light Wrist Chain (L)"
        }
    },
    "23": {
        "0": {
            "GXT": "CLO_BIM_PW_1_0",
            "Localized": "Chunky Wrist Chain (L)"
        }
    },
    "24": {
        "0": {
            "GXT": "CLO_BIM_PW_2_0",
            "Localized": "Square Wrist Chain (L)"
        }
    },
    "25": {
        "0": {
            "GXT": "CLO_BIM_PW_3_0",
            "Localized": "Skull Wrist Chain (L)"
        }
    },
    "26": {
        "0": {
            "GXT": "CLO_BIM_PW_4_0",
            "Localized": "Tread Wrist Chain (L)"
        }
    },
    "27": {
        "0": {
            "GXT": "CLO_BIM_PW_5_0",
            "Localized": "Gear Wrist Chains (L)"
        }
    },
    "28": {
        "0": {
            "GXT": "CLO_BIM_PW_6_0",
            "Localized": "Spiked Gauntlet (L)"
        }
    },
    "29": {
        "0": {
            "GXT": "CLO_BIM_PW_7_0",
            "Localized": "Black Gauntlet (L)"
        },
        "1": {
            "GXT": "CLO_BIM_PW_7_1",
            "Localized": "Chocolate Gauntlet (L)"
        },
        "2": {
            "GXT": "CLO_BIM_PW_7_2",
            "Localized": "Tan Gauntlet (L)"
        },
        "3": {
            "GXT": "CLO_BIM_PW_7_3",
            "Localized": "Ox Blood Gauntlet (L)"
        }
    },
    "30": {
        "0": {
            "GXT": "CLO_VWM_PW_0_0",
            "Localized": "Gold Enduring Watch"
        },
        "1": {
            "GXT": "CLO_VWM_PW_0_1",
            "Localized": "Silver Enduring Watch"
        },
        "2": {
            "GXT": "CLO_VWM_PW_0_2",
            "Localized": "Black Enduring Watch"
        },
        "3": {
            "GXT": "CLO_VWM_PW_0_3",
            "Localized": "Deck Enduring Watch"
        },
        "4": {
            "GXT": "CLO_VWM_PW_0_4",
            "Localized": "Royal Enduring Watch"
        },
        "5": {
            "GXT": "CLO_VWM_PW_0_5",
            "Localized": "Roulette Enduring Watch"
        }
    },
    "31": {
        "0": {
            "GXT": "CLO_VWM_PW_1_0",
            "Localized": "Gold Kronos Tempo"
        },
        "1": {
            "GXT": "CLO_VWM_PW_1_1",
            "Localized": "Silver Kronos Tempo"
        },
        "2": {
            "GXT": "CLO_VWM_PW_1_2",
            "Localized": "Black Kronos Tempo"
        },
        "3": {
            "GXT": "CLO_VWM_PW_1_3",
            "Localized": "Gold Fifty Kronos Tempo"
        },
        "4": {
            "GXT": "CLO_VWM_PW_1_4",
            "Localized": "Gold Roulette Kronos Tempo"
        },
        "5": {
            "GXT": "CLO_VWM_PW_1_5",
            "Localized": "Baroque Kronos Tempo"
        }
    },
    "32": {
        "0": {
            "GXT": "CLO_VWM_PW_2_0",
            "Localized": "Gold Kronos Pulse"
        },
        "1": {
            "GXT": "CLO_VWM_PW_2_1",
            "Localized": "Silver Kronos Pulse"
        },
        "2": {
            "GXT": "CLO_VWM_PW_2_2",
            "Localized": "Black Kronos Pulse"
        },
        "3": {
            "GXT": "CLO_VWM_PW_2_3",
            "Localized": "Silver Fifty Kronos Pulse"
        },
        "4": {
            "GXT": "CLO_VWM_PW_2_4",
            "Localized": "Silver Roulette Kronos Pulse"
        },
        "5": {
            "GXT": "CLO_VWM_PW_2_5",
            "Localized": "Spade Kronos Pulse"
        },
        "6": {
            "GXT": "CLO_VWM_PW_2_6",
            "Localized": "Red Fame or Shame Kronos"
        },
        "7": {
            "GXT": "CLO_VWM_PW_2_7",
            "Localized": "Green Fame or Shame Kronos"
        },
        "8": {
            "GXT": "CLO_VWM_PW_2_8",
            "Localized": "Blue Fame or Shame Kronos"
        },
        "9": {
            "GXT": "CLO_VWM_PW_2_9",
            "Localized": "Black Fame or Shame Kronos"
        }
    },
    "33": {
        "0": {
            "GXT": "CLO_VWM_PW_3_0",
            "Localized": "Gold Kronos Ära"
        },
        "1": {
            "GXT": "CLO_VWM_PW_3_1",
            "Localized": "Silver Kronos Ära"
        },
        "2": {
            "GXT": "CLO_VWM_PW_3_2",
            "Localized": "Black Kronos Ära"
        },
        "3": {
            "GXT": "CLO_VWM_PW_3_3",
            "Localized": "Gold Fifty Kronos Ära"
        },
        "4": {
            "GXT": "CLO_VWM_PW_3_4",
            "Localized": "Tan Spade Kronos Ära"
        },
        "5": {
            "GXT": "CLO_VWM_PW_3_5",
            "Localized": "Brown Spade Kronos Ära"
        }
    },
    "34": {
        "0": {
            "GXT": "CLO_VWM_PW_4_0",
            "Localized": "Gold Ceaseless"
        },
        "1": {
            "GXT": "CLO_VWM_PW_4_1",
            "Localized": "Silver Ceaseless"
        },
        "2": {
            "GXT": "CLO_VWM_PW_4_2",
            "Localized": "Black Ceaseless"
        },
        "3": {
            "GXT": "CLO_VWM_PW_4_3",
            "Localized": "Spade Ceaseless"
        },
        "4": {
            "GXT": "CLO_VWM_PW_4_4",
            "Localized": "Mixed Metals Ceaseless"
        },
        "5": {
            "GXT": "CLO_VWM_PW_4_5",
            "Localized": "Roulette Ceaseless"
        }
    },
    "35": {
        "0": {
            "GXT": "CLO_VWM_PW_5_0",
            "Localized": "Silver Crowex Époque"
        },
        "1": {
            "GXT": "CLO_VWM_PW_5_1",
            "Localized": "Gold Crowex Époque"
        },
        "2": {
            "GXT": "CLO_VWM_PW_5_2",
            "Localized": "Black Crowex Époque"
        },
        "3": {
            "GXT": "CLO_VWM_PW_5_3",
            "Localized": "Wheel Crowex Époque"
        },
        "4": {
            "GXT": "CLO_VWM_PW_5_4",
            "Localized": "Suits Crowex Époque"
        },
        "5": {
            "GXT": "CLO_VWM_PW_5_5",
            "Localized": "Roulette Crowex Époque"
        }
    },
    "36": {
        "0": {
            "GXT": "CLO_VWM_PW_6_0",
            "Localized": "Gold Kronos Quad"
        },
        "1": {
            "GXT": "CLO_VWM_PW_6_1",
            "Localized": "Silver Kronos Quad"
        },
        "2": {
            "GXT": "CLO_VWM_PW_6_2",
            "Localized": "Black Kronos Quad"
        },
        "3": {
            "GXT": "CLO_VWM_PW_6_3",
            "Localized": "Roulette Kronos Quad"
        },
        "4": {
            "GXT": "CLO_VWM_PW_6_4",
            "Localized": "Fifty Kronos Quad"
        },
        "5": {
            "GXT": "CLO_VWM_PW_6_5",
            "Localized": "Suits Kronos Quad"
        }
    },
    "37": {
        "0": {
            "GXT": "CLO_VWM_PW_7_0",
            "Localized": "Silver Crowex Rond"
        },
        "1": {
            "GXT": "CLO_VWM_PW_7_1",
            "Localized": "Gold Crowex Rond"
        },
        "2": {
            "GXT": "CLO_VWM_PW_7_2",
            "Localized": "Black Crowex Rond"
        },
        "3": {
            "GXT": "CLO_VWM_PW_7_3",
            "Localized": "Spade Crowex Rond"
        },
        "4": {
            "GXT": "CLO_VWM_PW_7_4",
            "Localized": "Royalty Crowex Rond"
        },
        "5": {
            "GXT": "CLO_VWM_PW_7_5",
            "Localized": "Dice Crowex Rond"
        }
    },
    "38": {
        "0": {
            "GXT": "CLO_VWM_PW_8_0",
            "Localized": "Silver SASS Wrist Piece"
        },
        "1": {
            "GXT": "CLO_VWM_PW_8_1",
            "Localized": "Gold SASS Wrist Piece"
        },
        "2": {
            "GXT": "CLO_VWM_PW_8_2",
            "Localized": "Black SASS Wrist Piece"
        }
    },
    "39": {
        "0": {
            "GXT": "CLO_VWM_PW_9_0",
            "Localized": "Silver SASS Bracelet"
        },
        "1": {
            "GXT": "CLO_VWM_PW_9_1",
            "Localized": "Gold SASS Bracelet"
        },
        "2": {
            "GXT": "CLO_VWM_PW_9_2",
            "Localized": "Black SASS Bracelet"
        }
    },
    "40": {
        "0": {
            "GXT": "CLO_H4M_PLW_0_0",
            "Localized": "Blue Bangles (L)"
        },
        "1": {
            "GXT": "CLO_H4M_PLW_0_1",
            "Localized": "Red Bangles (L)"
        },
        "2": {
            "GXT": "CLO_H4M_PLW_0_2",
            "Localized": "Pink Bangles (L)"
        },
        "3": {
            "GXT": "CLO_H4M_PLW_0_3",
            "Localized": "Yellow Bangles (L)"
        },
        "4": {
            "GXT": "CLO_H4M_PLW_0_4",
            "Localized": "Orange Bangles (L)"
        },
        "5": {
            "GXT": "CLO_H4M_PLW_0_5",
            "Localized": "Green Bangles (L)"
        },
        "6": {
            "GXT": "CLO_H4M_PLW_0_6",
            "Localized": "Red & Blue Bangles (L)"
        },
        "7": {
            "GXT": "CLO_H4M_PLW_0_7",
            "Localized": "Yellow & Orange Bangles (L)"
        },
        "8": {
            "GXT": "CLO_H4M_PLW_0_8",
            "Localized": "Green & Pink Bangles (L)"
        },
        "9": {
            "GXT": "CLO_H4M_PLW_0_9",
            "Localized": "Rainbow Bangles (L)"
        },
        "10": {
            "GXT": "CLO_H4M_PLW_010",
            "Localized": "Sunset Bangles (L)"
        },
        "11": {
            "GXT": "CLO_H4M_PLW_011",
            "Localized": "Tropical Bangles (L)"
        }
    }
}
`